# JARVIS — SAMSUNG GALAXY A73 5G VE ANDROID KURULUM REHBERİ

Tebrikler! Kişisel yapay zekâ asistanınız **JARVIS**, modern Android standartlarına, Jetpack Compose mimarisine, Türkçe ses sistemine ve sıfır-güven (Zero-Trust) onay protokollerine uygun olarak başarıyla inşa edilmiştir.

---

## 1. MİMARİ GENEL BAKIŞ
JARVIS sistemi iki ana parçadan oluşur:
1. **Android Uygulaması (Client):** Samsung Galaxy A73 5G telefonunuzda çalışır. Fütüristik bilim kurgu HUD arayüzü, Türkçe ses tanıma (SpeechRecognizer), Türkçe sesli yanıt (TextToSpeech), yerel Room veritabanı (Notlar, Görevler, Sohbet Geçmişi) ve **ActionApprovalManager (Zorunlu İşlem Onay Sistemi)** barındırır.
2. **Cloudflare Worker Arka Ucu (Backend):** `worker/` klasöründe yer alır. Google Gemini AI, Cloudflare Workers AI (Görsel Üretimi) ve Tuya Cloud API (Smart Life Akıllı Ev) isteklerini yönetir. **Gizli API anahtarları asla APK içine gömülmez.**

---

## 2. ADIM ADIM KURULUM

### ADIM 1: Google Gemini API Anahtarı Alma
1. [aistudio.google.com](https://aistudio.google.com/) adresine Google hesabınızla giriş yapın.
2. Sol menüden **Get API key** butonuna tıklayın.
3. **Create API key in new project** seçeneğiyle yeni bir anahtar oluşturun ve kopyalayın (`AIzaSy...`).
4. *Not:* Ücretsiz planda dakikada 15 istek sınırı vardır; kişisel asistan kullanımı için tamamen yeterlidir.

### ADIM 2: Cloudflare Worker Arka Ucunu Yayına Alma
Worker'ı bilgisayarla veya sadece telefonunuzun web tarayıcısını kullanarak 2 dakikada yayına alabilirsiniz:

#### Telefon Üzerinden (Bilgisayarsız Yöntem):
1. Telefonunuzun tarayıcısından [dash.cloudflare.com](https://dash.cloudflare.com) adresine girin.
2. **Compute (Workers & Pages)** > **Create Worker** butonuna dokunun.
3. Adını `jarvis-backend` yapın ve **Deploy** deyin.
4. Worker sayfasında **Edit code** butonuna basın. Projedeki `worker/src/index.js` dosyasının içeriğini yapıştırıp **Save and deploy** yapın.
5. **Settings** > **Variables and Secrets** alanına gidin ve şunları ekleyin:
   * `GEMINI_API_KEY`: 1. adımda aldığınız anahtar
   * `JARVIS_CLIENT_TOKEN`: Kendi belirleyeceğiniz gizli bir parola (örn: `jarvis2026`)
   * `TUYA_ACCESS_ID`: Tuya Cloud Access ID (Tuya kullanıyorsanız)
   * `TUYA_ACCESS_SECRET`: Tuya Cloud Access Secret
6. **Settings** > **Bindings** sekmesinden:
   * **Add binding** > **Workers AI** seçin ve Variable name olarak `AI` yazın.
7. Size verilen URL'yi not edin (Örn: `https://jarvis-backend.kullanici.workers.dev`).

### ADIM 3: Tuya Cloud & Smart Life Entegrasyonu (İsteğe Bağlı)
1. [iot.tuya.com](https://iot.tuya.com/) adresinde ücretsiz bir geliştirici hesabı açın.
2. **Cloud** > **Development** > **Create Cloud Project** adımlarını izleyin.
3. Proje oluşturduktan sonra **Overview** sekmesinden `Access ID / Client ID` ve `Access Secret` değerlerini alın.
4. **Link Tuya App Account** sekmesine gidip telefonunuzdaki Smart Life uygulamasındaki QR kodu okutarak cihazlarınızı projeye bağlayın.
5. Bu bilgileri Cloudflare Worker gizli değişkenlerine (`TUYA_ACCESS_ID`, `TUYA_ACCESS_SECRET`) ekleyin.

---

## 3. APK ÜRETME VE TELEFONA YÜKLEME

### A. Google AI Studio Üzerinden Doğrudan İndirme (En Kolay Yol - Bilgisayarsız)
1. Ekranın sağ üst köşesindeki ayarlar veya dışa aktarma simgesine dokunun.
2. **Export as APK** veya **Download ZIP** seçeneğini seçin.
3. İndirdiğiniz `.apk` dosyasını Samsung Galaxy A73 5G telefonunuzun Dosyalarım (My Files) uygulamasında açarak "Yükle" deyin.
4. "Bilinmeyen kaynaklardan yükleme" uyarısı çıkarsa izin verin.

### B. Bilgisayar ile Derleme (Android Studio veya Terminal)
```bash
# Debug APK derleme komutu:
gradle assembleDebug
```
Üretilen dosya konumu: `app/build/outputs/apk/debug/app-debug.apk`

---

## 4. İLK AÇILIŞ VE TELEFONDA KULLANIM

1. Uygulamayı açtığınızda JARVIS Sci-Fi Arc Reaktör HUD karşınıza çıkar.
2. Mikrofon ve Kamera izinleri istendiğinde onay verin.
3. Sağ üstteki **Ayarlar** simgesine dokunun:
   * **Cloudflare Worker URL:** 2. Adımda aldığınız adresi girin.
   * **Worker Token:** Belirlediğiniz şifreyi girin.
   * **Bağlantıyı Test Et** butonuna basın ve `ÇEVRİMİÇİ` onayını görün.
   * *(Alternatif olarak Worker kurmadan doğrudan Gemini API anahtarınızı da girebilirsiniz)*
4. Ana ekrana dönün.

### Deneyebileceğiniz Örnek Türkçe Komutlar:
* **Sesli Sohbet:** Mikrofon simgesine basıp konuşun veya ön plandayken *"Jarvis, bugün hava durumu nasıl?"* deyin.
* **Fener Kontrolü:** *"Jarvis, feneri aç."* -> JARVIS onay diyaloğunu açar: *"Feneri açmamı onaylıyor musunuz?"* -> **EVET, ONAYLA** butonuna basarak feneri açın.
* **Uygulama Açma:** *"YouTube uygulamasını aç."* -> Onay ekranı ile açılır.
* **Arama Yapma:** *"112'yi ara."* -> Numara arama ekranına aktarılır.
* **Görsel Üretimi:** *"Görsel üret: Neon ışıklı fütüristik araba."* -> Cloudflare Workers AI görseli üretir ve ekranda gösterir.
* **Akıllı Ev:** *"Salon ışığını kapat."* -> Tuya API üzerinden onaylı olarak iletilir.
* **Çevrimdışı Notlar:** "Hafıza" sekmesine gidip internet olmadan not ve görevlerinizi kaydedin.
