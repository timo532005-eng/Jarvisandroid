/**
 * JARVIS Cloudflare Worker Backend
 * Güvenli Proxy: Google Gemini API, Workers AI Görsel Üretimi, Tuya Smart Life Entegrasyonu
 */

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Jarvis-Token",
};

export default {
  async fetch(request, env, ctx) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: CORS_HEADERS });
    }

    const url = new URL(request.url);
    const pathname = url.pathname;

    try {
      // 1. Sağlık Kontrolü
      if (pathname === "/health" || pathname === "/") {
        return jsonResponse({
          status: "ONLINE",
          service: "JARVIS Core Worker",
          version: "1.0.0",
          features: {
            gemini_configured: Boolean(env.GEMINI_API_KEY),
            workers_ai_available: Boolean(env.AI),
            tuya_configured: Boolean(env.TUYA_ACCESS_ID && env.TUYA_ACCESS_SECRET),
          },
          timestamp: new Date().toISOString()
        });
      }

      // 2. Güvenlik Doğrulaması (Token Kontrolü)
      if (env.JARVIS_CLIENT_TOKEN) {
        const clientToken = request.headers.get("X-Jarvis-Token") || 
          request.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
        if (!clientToken || clientToken !== env.JARVIS_CLIENT_TOKEN) {
          return errorResponse("Yetkisiz erişim: Geçersiz veya eksik JARVIS token.", 401);
        }
      }

      // 3. Gemini Sohbet Uç Noktası
      if (pathname === "/api/chat" && request.method === "POST") {
        return await handleChat(request, env);
      }

      // 4. Cloudflare Workers AI Görsel Üretimi
      if (pathname === "/api/generate-image" && request.method === "POST") {
        return await handleImageGeneration(request, env);
      }

      // 5. Tuya Cihazları Listeleme
      if (pathname === "/api/tuya/devices" && request.method === "GET") {
        return await handleTuyaDevices(request, env);
      }

      // 6. Tuya Cihaz Komutu Gönderme
      if (pathname === "/api/tuya/command" && request.method === "POST") {
        return await handleTuyaCommand(request, env);
      }

      return errorResponse("Uç nokta bulunamadı: " + pathname, 404);
    } catch (err) {
      return errorResponse("Worker Dahili Hatası: " + (err.message || String(err)), 500);
    }
  }
};

/**
 * -----------------------------------------------------------------------------
 * GEMINI SOHBET İŞLEYİCİSİ
 * -----------------------------------------------------------------------------
 */
async function handleChat(request, env) {
  if (!env.GEMINI_API_KEY) {
    return errorResponse("Worker üzerinde GEMINI_API_KEY tanımlanmamış.", 503);
  }

  const body = await request.json().catch(() => null);
  if (!body || !Array.isArray(body.messages) || body.messages.length === 0) {
    return errorResponse("Geçersiz istek: 'messages' dizisi gereklidir.", 400);
  }

  const userModel = body.model || "gemini-2.5-flash";
  const geminiEndpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(userModel)}:generateContent?key=${env.GEMINI_API_KEY}`;

  // Sistem Talimatı: JARVIS Kimliği ve Eylem Öneri Formatı
  const systemInstruction = `Sen JARVIS'sin. Kullanıcının Türkçe konuşan, yüksek zekâlı, kibar, profesyonel, fütüristik bilim kurgu kişisel yapay zekâ asistanısın.
Kullanıcıya daima saygılı, net, Türkçe yanıt ver.
ÖNEMLİ GÜVENLİK KURALI: Kullanıcı telefonunda bir işlem yapmanı veya akıllı ev cihazını kontrol etmeni isterse, bu işlemi doğrudan çalıştırma. Bunun yerine yanıtının en sonuna aşağıdaki yapılandırılmış eylem etiketini ekle:
[ACTION:FLASHLIGHT:ON] veya [ACTION:FLASHLIGHT:OFF]
[ACTION:OPEN_APP:UygulamaAdı] (Örnek: [ACTION:OPEN_APP:WhatsApp], [ACTION:OPEN_APP:YouTube])
[ACTION:DIAL:TelefonNumarası] (Örnek: [ACTION:DIAL:112])
[ACTION:SMS:Numara:MesajMetni]
[ACTION:ALARM:Saat(HH:mm):Açıklama] (Örnek: [ACTION:ALARM:07:30:Sabah Uyanma])
[ACTION:TIMER:Saniye:Açıklama]
[ACTION:IMAGE_GEN:İngilizcePrompt]
[ACTION:TUYA:CihazKimliğiVeyaAdı:Komut:Değer] (Örnek: [ACTION:TUYA:salon_isigi:switch_led:true])

Kullanıcıya cevabında da eylemi gerçekleştirmeden önce açıkça soracağını belirt (Örn: "Salon lambasını açmak üzeresiniz. Onaylıyor musunuz?").`;

  // Gemini API Formatına Dönüştürme
  const contents = body.messages.map(msg => ({
    role: msg.role === "assistant" ? "model" : "user",
    parts: [{ text: msg.content }]
  }));

  const geminiPayload = {
    contents: contents,
    systemInstruction: {
      parts: [{ text: systemInstruction }]
    },
    generationConfig: {
      temperature: 0.7,
      maxOutputTokens: 1024,
    }
  };

  const response = await fetch(geminiEndpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(geminiPayload)
  });

  if (!response.ok) {
    const errorText = await response.text();
    return errorResponse(`Gemini API Hatası (${response.status}): ${errorText}`, response.status);
  }

  const data = await response.json();
  const candidate = data.candidates?.[0];
  const fullText = candidate?.content?.parts?.[0]?.text || "Jarvis şu an yanıt üretemedi.";

  // Eylem Etiketini Ayrıştırma
  const actionMatch = fullText.match(/\[ACTION:([^\]]+)\]/);
  let parsedAction = null;
  let cleanText = fullText;

  if (actionMatch) {
    const actionParts = actionMatch[1].split(":");
    const actionType = actionParts[0];
    parsedAction = {
      type: actionType,
      param1: actionParts[1] || "",
      param2: actionParts[2] || "",
      param3: actionParts[3] || "",
      raw: actionMatch[0]
    };
    cleanText = fullText.replace(actionMatch[0], "").trim();
  }

  return jsonResponse({
    reply: cleanText,
    action: parsedAction,
    usage: data.usageMetadata || null
  });
}

/**
 * -----------------------------------------------------------------------------
 * WORKERS AI GÖRSEL ÜRETİMİ
 * -----------------------------------------------------------------------------
 */
async function handleImageGeneration(request, env) {
  if (!env.AI) {
    return errorResponse("Bu Cloudflare Worker üzerinde Workers AI (binding: AI) etkinleştirilmemiş.", 503);
  }

  const body = await request.json().catch(() => null);
  if (!body || !body.prompt || typeof body.prompt !== "string") {
    return errorResponse("Görsel üretimi için 'prompt' metni gereklidir.", 400);
  }

  const prompt = body.prompt.trim();
  const model = body.model || env.WORKERS_IMAGE_MODEL || "@cf/black-forest-labs/flux-1-schnell";

  try {
    const inputs = {
      prompt: prompt,
      steps: 4
    };

    // Workers AI çağrısı binary ArrayBuffer / Uint8Array döndürür
    const imageBuffer = await env.AI.run(model, inputs);

    // ArrayBuffer'ı base64'e dönüştür
    const bytes = new Uint8Array(imageBuffer);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64Data = btoa(binary);

    return jsonResponse({
      success: true,
      prompt: prompt,
      model: model,
      mime_type: "image/jpeg",
      image_base64: `data:image/jpeg;base64,${base64Data}`
    });
  } catch (err) {
    return errorResponse("Workers AI Görsel Üretimi Hatası: " + err.message, 500);
  }
}

/**
 * -----------------------------------------------------------------------------
 * TUYA CLOUD API ENTEGRASYONU (Smart Life)
 * -----------------------------------------------------------------------------
 */
async function handleTuyaDevices(request, env) {
  if (!env.TUYA_ACCESS_ID || !env.TUYA_ACCESS_SECRET) {
    return errorResponse("Worker üzerinde TUYA_ACCESS_ID ve TUYA_ACCESS_SECRET tanımlanmamış.", 503);
  }

  const endpoint = env.TUYA_ENDPOINT || "https://openapi.tuyaeu.com";
  const token = await getTuyaToken(env, endpoint);
  if (!token) {
    return errorResponse("Tuya erişim token'ı alınamadı. API kimlik bilgilerinizi kontrol edin.", 502);
  }

  // Kullanıcının veya projenin cihazlarını getir
  const path = env.TUYA_UID 
    ? `/v1.0/users/${encodeURIComponent(env.TUYA_UID)}/devices` 
    : `/v1.0/devices`;

  const result = await makeTuyaSignedRequest(env, endpoint, token, "GET", path);
  if (!result.success) {
    return errorResponse(`Tuya Cihazları Alınamadı: ${result.msg || "Bilinmeyen hata"}`, 502);
  }

  const devices = (result.result?.list || result.result || []).map(d => ({
    id: d.id,
    name: d.name,
    category: d.category,
    online: d.online,
    status: d.status || []
  }));

  return jsonResponse({
    success: true,
    devices: devices
  });
}

async function handleTuyaCommand(request, env) {
  if (!env.TUYA_ACCESS_ID || !env.TUYA_ACCESS_SECRET) {
    return errorResponse("Tuya kimlik bilgileri eksik.", 503);
  }

  const body = await request.json().catch(() => null);
  if (!body || !body.device_id || !Array.isArray(body.commands)) {
    return errorResponse("Geçersiz istek: 'device_id' ve 'commands' dizisi gereklidir.", 400);
  }

  const endpoint = env.TUYA_ENDPOINT || "https://openapi.tuyaeu.com";
  const token = await getTuyaToken(env, endpoint);
  if (!token) {
    return errorResponse("Tuya token alınamadı.", 502);
  }

  const path = `/v1.0/devices/${encodeURIComponent(body.device_id)}/commands`;
  const result = await makeTuyaSignedRequest(env, endpoint, token, "POST", path, { commands: body.commands });

  return jsonResponse({
    success: result.success === true,
    device_id: body.device_id,
    message: result.msg || (result.success ? "Komut başarıyla iletildi." : "Komut iletilemedi."),
    result: result.result
  });
}

/**
 * Tuya HMAC-SHA256 Token İsteme
 */
async function getTuyaToken(env, endpoint) {
  const timestamp = Date.now().toString();
  const signUrl = "/v1.0/token?grant_type=1";
  const stringToSign = ["GET", "", "", signUrl].join("\n");
  const sign = await tuyaHmacSha256(env.TUYA_ACCESS_ID + timestamp + stringToSign, env.TUYA_ACCESS_SECRET);

  const res = await fetch(`${endpoint}${signUrl}`, {
    method: "GET",
    headers: {
      "client_id": env.TUYA_ACCESS_ID,
      "sign": sign,
      "t": timestamp,
      "sign_method": "HMAC-SHA256"
    }
  });

  const data = await res.json().catch(() => null);
  if (data && data.success && data.result?.access_token) {
    return data.result.access_token;
  }
  return null;
}

/**
 * Tuya İmzalı İstek Gönderme
 */
async function makeTuyaSignedRequest(env, endpoint, token, method, path, body = null) {
  const timestamp = Date.now().toString();
  const bodyHash = body 
    ? await sha256Hex(JSON.stringify(body)) 
    : "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"; // Empty hash

  const stringToSign = [method, bodyHash, "", path].join("\n");
  const sign = await tuyaHmacSha256(env.TUYA_ACCESS_ID + token + timestamp + stringToSign, env.TUYA_ACCESS_SECRET);

  const headers = {
    "client_id": env.TUYA_ACCESS_ID,
    "access_token": token,
    "sign": sign,
    "t": timestamp,
    "sign_method": "HMAC-SHA256",
    "Content-Type": "application/json"
  };

  const options = { method, headers };
  if (body) {
    options.body = JSON.stringify(body);
  }

  const res = await fetch(`${endpoint}${path}`, options);
  return await res.json().catch(err => ({ success: false, msg: err.message }));
}

/**
 * Şifreleme Yardımcıları (Web Crypto API)
 */
async function tuyaHmacSha256(message, secret) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", key, enc.encode(message));
  return Array.from(new Uint8Array(signature)).map(b => b.toString(16).padStart(2, "0")).join("").toUpperCase();
}

async function sha256Hex(message) {
  const enc = new TextEncoder();
  const hash = await crypto.subtle.digest("SHA-256", enc.encode(message));
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status: status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
  });
}

function errorResponse(message, status = 400) {
  return new Response(JSON.stringify({ error: message, success: false }), {
    status: status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
  });
}
