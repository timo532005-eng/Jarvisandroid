# JARVIS Cloudflare Worker Arka Ucu

Bu proje, JARVIS Android uygulamasının güvenli köprüsüdür.
Google Gemini API, Cloudflare Workers AI ve Tuya Cloud (Smart Life) servislerine yapılacak istekleri Android APK'sı içine anahtar gömmeden güvenle yönetir.

---

## 1. Neden Cloudflare Worker?
* **Sıfır APK İçi Gizli Anahtar:** Gemini, Tuya ve Cloudflare token'ları APK içinde asla saklanmaz.
* **Ücretsiz Başlangıç:** Cloudflare Workers ücretsiz planda günde 100.000 istek sunar.
* **Onay Güvenliği:** Eylemler (telefon ve Tuya komutları) doğrudan yürütülmez; yapılandırılmış eylem önerisi olarak Android'e döner ve Android'de ActionApprovalManager tarafından açık kullanıcı onayı ile kilitlenir.

---

## 2. Kurulum ve Dağıtım Adımları

### A. Bilgisayar ile Kurulum (Önerilen)
1. **Node.js ve Wrangler Yükleyin:**
   ```bash
   npm install -g wrangler
   ```

2. **Cloudflare Hesabınıza Giriş Yapın:**
   ```bash
   wrangler login
   ```

3. **Gizli Anahtarları Tanımlayın:**
   ```bash
   # 1. Gemini API Anahtarı:
   wrangler secret put GEMINI_API_KEY

   # 2. İstemci Güvenlik Tokenı (Android ayarlarında da aynı değeri gireceksiniz):
   wrangler secret put JARVIS_CLIENT_TOKEN

   # 3. Tuya Akıllı Ev Bilgileri (İsteğe bağlı - Tuya kullanıyorsanız):
   wrangler secret put TUYA_ACCESS_ID
   wrangler secret put TUYA_ACCESS_SECRET
   ```

4. **Dağıtımı Gerçekleştirin:**
   ```bash
   wrangler deploy
   ```
   Dağıtım tamamlandığında size özel bir URL verilecektir (Örnek: `https://jarvis-backend.kullaniciadi.workers.dev`).

---

### B. Bilgisayarsız (Yalnızca Telefon / Web Tarayıcısı ile) Kurulum
1. [dash.cloudflare.com](https://dash.cloudflare.com) adresine telefonunuzun tarayıcısından girin.
2. Sol menüden **Compute (Workers & Pages)** > **Create Worker** butonuna dokunun.
3. Adını `jarvis-backend` yapın ve **Deploy** deyin.
4. Worker oluştuktan sonra **Edit code** butonuna basın.
5. `src/index.js` dosyasındaki kodları kopyalayıp web editörüne yapıştırın ve **Save and deploy** yapın.
6. Worker sayfasında **Settings** > **Variables and Secrets** sekmesine gidin.
   Aşağıdaki değişkenleri "Add" diyerek ekleyin (Secret olarak işaretleyin):
   * `GEMINI_API_KEY`: Google AI Studio'dan aldığınız API anahtarı
   * `JARVIS_CLIENT_TOKEN`: Kendi belirlediğiniz gizli bir şifre (örn: `jarvis1234`)
   * `TUYA_ACCESS_ID`: Tuya Cloud Access ID
   * `TUYA_ACCESS_SECRET`: Tuya Cloud Access Secret
7. **Settings** > **Bindings** sekmesinden Workers AI için:
   * **Add binding** > **Workers AI** seçin ve Variable name olarak `AI` yazın.

---

## 3. Android Uygulamasına Bağlama
1. APK'yı telefonunuza yükleyip JARVIS'i açın.
2. Sağ üstteki veya alt menüdeki **Ayarlar (Settings)** ekranına dokunun.
3. **Cloudflare Worker URL** alanına dağıttığınız Worker adresini girin:
   `https://jarvis-backend.kullaniciadi.workers.dev`
4. **Güvenlik Token'ı** alanına belirlediğiniz `JARVIS_CLIENT_TOKEN` değerini yazın.
5. "Bağlantıyı Test Et" butonuna dokunarak `ONLINE` durumunu görün.
