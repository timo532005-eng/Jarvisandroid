package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricalServices
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.TuyaDeviceDto
import com.example.ui.JarvisViewModel
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisAqua
import com.example.ui.theme.JarvisBorder
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisPanelDark
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.ui.theme.JarvisVoidBlack

@Composable
fun SmartHomeScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val devices by viewModel.tuyaDevices.collectAsState()
    val isLoading by viewModel.isTuyaLoading.collectAsState()
    val settings by viewModel.settings.collectAsState()

    LaunchedEffect(Unit) {
        if (devices.isEmpty() && settings.workerBaseUrl.isNotBlank()) {
            viewModel.refreshTuyaDevices()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisVoidBlack)
            .padding(horizontal = 16.dp)
    ) {
        // Üst Başlık Barı
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "AKILLI EV // TUYA CLOUD",
                    color = JarvisCyan,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Smart Life & Tuya IoT Entegrasyonu",
                    color = JarvisTextSecondary,
                    fontSize = 11.sp
                )
            }

            IconButton(
                onClick = { viewModel.refreshTuyaDevices() },
                enabled = !isLoading,
                modifier = Modifier.size(36.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = JarvisCyan, strokeWidth = 2.dp)
                } else {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Cihazları Yenile",
                        tint = JarvisCyan
                    )
                }
            }
        }

        // Güvenlik & Onay Hatırlatması
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(BorderStroke(1.dp, JarvisBorderSubtle), RoundedCornerShape(8.dp)),
            color = JarvisPanelDark
        ) {
            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "🛡️ Güvenlik Kuralı: Cihazlara gönderilecek her açma/kapama komutu önce ActionApprovalManager tarafından açıkça onayınıza sunulur.",
                    color = JarvisTextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Cihaz Listesi
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (devices.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (settings.workerBaseUrl.isBlank())
                                "Cloudflare Worker URL tanımlanmamış.\nLütfen Ayarlar ekranından Worker adresinizi girin."
                            else
                                "Henüz keşfedilmiş Tuya cihazı bulunamadı.\nWorker üzerindeki TUYA_ACCESS_ID ve SECRET ayarlarını kontrol edip Yenile butonuna basın.",
                            color = JarvisTextSecondary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Örnek / Simülasyon Test Cihazları Ekleme (Kullanıcı Tuya'yı test edebilsin)
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .border(BorderStroke(1.dp, JarvisCyan), RoundedCornerShape(8.dp))
                                .clickable {
                                    // Örnek Tuya cihazı test komutu
                                    viewModel.proposeTuyaAction("salon_isigi", "switch_led", "true")
                                },
                            color = JarvisSurfaceElevated
                        ) {
                            Text(
                                text = "💡 Örnek Salon Lambası Onay Testi",
                                color = JarvisCyan,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            items(devices, key = { it.id }) { device ->
                TuyaDeviceItem(
                    device = device,
                    onToggle = { turnOn ->
                        viewModel.proposeTuyaAction(
                            deviceIdOrName = device.id,
                            command = "switch_led",
                            value = turnOn.toString()
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun TuyaDeviceItem(
    device: TuyaDeviceDto,
    onToggle: (Boolean) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, JarvisBorder), RoundedCornerShape(12.dp)),
        color = JarvisPanelDark
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(JarvisSurfaceElevated)
                        .border(BorderStroke(1.dp, JarvisBorderSubtle), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (device.category?.contains("dj") == true || device.name.lowercase().contains("lamba") || device.name.lowercase().contains("ışık"))
                            Icons.Default.Lightbulb
                        else
                            Icons.Default.ElectricalServices,
                        contentDescription = null,
                        tint = if (device.online) JarvisCyan else Color.Gray,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = device.name,
                        color = JarvisTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (device.online) JarvisAqua else JarvisAlertRed)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (device.online) "ÇEVRİMİÇİ" else "ÇEVRİMDIŞI",
                            color = if (device.online) JarvisAqua else JarvisAlertRed,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Onaylı Kontrol Butonları
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .border(BorderStroke(1.dp, JarvisAqua), RoundedCornerShape(6.dp))
                        .clickable { onToggle(true) }
                        .testTag("tuya_open_${device.id}"),
                    color = JarvisAqua.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "AÇ",
                        color = JarvisAqua,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .border(BorderStroke(1.dp, JarvisAlertRed), RoundedCornerShape(6.dp))
                        .clickable { onToggle(false) }
                        .testTag("tuya_close_${device.id}"),
                    color = JarvisAlertRed.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "KAPAT",
                        color = JarvisAlertRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}
