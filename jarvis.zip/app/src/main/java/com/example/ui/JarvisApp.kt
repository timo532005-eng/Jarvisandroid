package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.approval.ApprovalState
import com.example.ui.screens.ActionApprovalDialog
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotesTasksScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SmartHomeScreen
import com.example.ui.theme.JarvisAqua
import com.example.ui.theme.JarvisBorder
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisPanelDark
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.ui.theme.JarvisVoidBlack

@Composable
fun JarvisApp(
    viewModel: JarvisViewModel
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val approvalState by viewModel.approvalState.collectAsState()

    // Alt ekranlardayken Geri Tuşuna basınca Anasayfaya dön
    if (currentScreen != AppNavScreen.HOME) {
        BackHandler {
            viewModel.navigateTo(AppNavScreen.HOME)
        }
    }

    // Zorunlu Güvenlik Onay Modalı (Hangi ekranda olunursa olunsun en üstte gösterilir)
    if (approvalState is ApprovalState.Pending) {
        ActionApprovalDialog(
            pendingState = approvalState as ApprovalState.Pending,
            onConfirm = { viewModel.approvalManager.confirmCurrentAction() },
            onCancel = { viewModel.approvalManager.cancelCurrentAction() }
        )
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisVoidBlack),
        topBar = {
            JarvisTopBar(
                currentScreen = currentScreen,
                onSettingsClick = { viewModel.navigateTo(AppNavScreen.SETTINGS) }
            )
        },
        bottomBar = {
            JarvisBottomNav(
                currentScreen = currentScreen,
                onScreenSelected = { viewModel.navigateTo(it) }
            )
        },
        containerColor = JarvisVoidBlack
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppNavScreen.HOME -> HomeScreen(viewModel = viewModel)
                AppNavScreen.CHAT -> ChatScreen(viewModel = viewModel)
                AppNavScreen.SMART_HOME -> SmartHomeScreen(viewModel = viewModel)
                AppNavScreen.NOTES_TASKS -> NotesTasksScreen(viewModel = viewModel)
                AppNavScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun JarvisTopBar(
    currentScreen: AppNavScreen,
    onSettingsClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .border(BorderStroke(0.8.dp, JarvisBorderSubtle)),
        color = JarvisPanelDark
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Mini Reaktör Parıltı Glifi
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(JarvisCyan)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "J.A.R.V.I.S.",
                        color = JarvisCyan,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.5.sp
                    )
                    Text(
                        text = "AI NEURAL INTERFACE // v1.0",
                        color = JarvisTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }
            }

            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(JarvisSurfaceElevated)
                    .border(BorderStroke(1.dp, JarvisBorderSubtle), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Ayarlar",
                    tint = if (currentScreen == AppNavScreen.SETTINGS) JarvisCyan else JarvisTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun JarvisBottomNav(
    currentScreen: AppNavScreen,
    onScreenSelected: (AppNavScreen) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .border(BorderStroke(1.dp, JarvisBorderSubtle)),
        color = JarvisPanelDark
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(
                icon = Icons.Default.Home,
                label = "HUD",
                selected = currentScreen == AppNavScreen.HOME,
                onClick = { onScreenSelected(AppNavScreen.HOME) },
                testTag = "nav_home"
            )
            NavItem(
                icon = Icons.Default.Chat,
                label = "SOHBET",
                selected = currentScreen == AppNavScreen.CHAT,
                onClick = { onScreenSelected(AppNavScreen.CHAT) },
                testTag = "nav_chat"
            )
            NavItem(
                icon = Icons.Default.SmartButton,
                label = "AKILLI EV",
                selected = currentScreen == AppNavScreen.SMART_HOME,
                onClick = { onScreenSelected(AppNavScreen.SMART_HOME) },
                testTag = "nav_smart_home"
            )
            NavItem(
                icon = Icons.Default.Checklist,
                label = "HAFIZA",
                selected = currentScreen == AppNavScreen.NOTES_TASKS,
                onClick = { onScreenSelected(AppNavScreen.NOTES_TASKS) },
                testTag = "nav_notes_tasks"
            )
            NavItem(
                icon = Icons.Default.Settings,
                label = "AYARLAR",
                selected = currentScreen == AppNavScreen.SETTINGS,
                onClick = { onScreenSelected(AppNavScreen.SETTINGS) },
                testTag = "nav_settings"
            )
        }
    }
}

@Composable
fun NavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) JarvisCyan else JarvisTextSecondary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            color = if (selected) JarvisCyan else JarvisTextSecondary,
            fontSize = 9.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
        )
    }
}
