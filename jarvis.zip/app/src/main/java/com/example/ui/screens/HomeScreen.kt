package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.voice.AssistantVoiceState
import com.example.ui.JarvisViewModel
import com.example.ui.hud.ArcReactorHud
import com.example.ui.hud.HudCard
import com.example.ui.hud.HudStatusBadge
import com.example.ui.hud.SystemHudStatus
import com.example.ui.hud.WaveformVisualizer
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisAqua
import com.example.ui.theme.JarvisBorder
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisPanelDark
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.ui.theme.JarvisVoidBlack
import com.example.ui.theme.JarvisWarningAmber

@Composable
fun HomeScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val hudStatus by viewModel.hudStatus.collectAsState()
    val voiceState by viewModel.voiceManager.voiceState.collectAsState()
    val recognizedText by viewModel.voiceManager.lastRecognizedText.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    val noticeMessage by viewModel.latestNotice.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val isListening = voiceState == AssistantVoiceState.LISTENING
    val isSpeaking = voiceState == AssistantVoiceState.SPEAKING

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisVoidBlack)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Üst Bildirim / Hata Banner'ı
        AnimatedVisibility(visible = noticeMessage != null) {
            if (noticeMessage != null) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(BorderStroke(1.dp, JarvisAlertRed), RoundedCornerShape(8.dp)),
                    color = JarvisPanelDark
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = JarvisAlertRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = noticeMessage!!,
                            color = JarvisTextPrimary,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { viewModel.dismissNotice() }, modifier = Modifier.size(24.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = JarvisTextSecondary)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Durum Rozeti
        HudStatusBadge(status = hudStatus)

        Spacer(modifier = Modifier.height(16.dp))

        // Ana Reaktör ve Waveform Alanı
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Merkezi HUD Arc Reaktörü
            ArcReactorHud(
                status = hudStatus,
                size = 230.dp,
                onClick = {
                    if (isSpeaking) {
                        viewModel.voiceManager.stopSpeaking()
                    } else {
                        viewModel.voiceManager.startListeningCommand()
                    }
                }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Ses Dalga Formu (Canlı Audio Waveform)
            WaveformVisualizer(
                isActive = isListening || isSpeaking || isAiLoading,
                barColor = if (isSpeaking) JarvisAqua else JarvisCyan,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Algılanan Konuşma veya Cevap Önizlemesi
            if (recognizedText.isNotBlank()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .clip(RoundedCornerShape(10.dp))
                        .border(BorderStroke(0.8.dp, JarvisBorderSubtle), RoundedCornerShape(10.dp)),
                    color = JarvisSurfaceElevated.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = "\"$recognizedText\"",
                        color = JarvisCyan,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // Hızlı Komut Çipleri
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickChip(label = "🔦 Feneri Aç") { viewModel.proposeFlashlightAction(true) }
            QuickChip(label = "🔦 Feneri Kapat") { viewModel.proposeFlashlightAction(false) }
            QuickChip(label = "🎨 Görsel Çiz") { viewModel.setInputText("Görsel üret: Fütüristik siber şehir") }
            QuickChip(label = "▶️ YouTube") { viewModel.proposeAppLaunch("YouTube") }
            QuickChip(label = "💬 WhatsApp") { viewModel.proposeAppLaunch("WhatsApp") }
            QuickChip(label = "⏰ 08:00 Alarm") { viewModel.proposeAlarmAction("08:00", "Sabah Uyanma") }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Alt Giriş Barı (Mikrofon + Metin + Gönder)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Büyük Dokunsal Mikrofon Butonu (48dp+)
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(
                        if (isListening) JarvisAlertRed else JarvisCyan.copy(alpha = 0.15f)
                    )
                    .border(
                        BorderStroke(1.5.dp, if (isListening) JarvisAlertRed else JarvisCyan),
                        CircleShape
                    )
                    .clickable {
                        if (isSpeaking) {
                            viewModel.voiceManager.stopSpeaking()
                        } else if (isListening) {
                            viewModel.voiceManager.pause()
                        } else {
                            viewModel.voiceManager.startListeningCommand()
                        }
                    }
                    .testTag("voice_mic_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        isSpeaking -> Icons.Default.Stop
                        isListening -> Icons.Default.Mic
                        else -> Icons.Default.Mic
                    },
                    contentDescription = "Mikrofon",
                    tint = if (isListening) Color.White else JarvisCyan,
                    modifier = Modifier.size(26.dp)
                )
            }

            // Metin Giriş Alanı
            OutlinedTextField(
                value = inputText,
                onValueChange = { viewModel.setInputText(it) },
                placeholder = {
                    Text(
                        text = "Jarvis'e mesaj yazın...",
                        color = JarvisTextSecondary,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = JarvisCyan,
                    unfocusedBorderColor = JarvisBorder,
                    focusedTextColor = JarvisTextPrimary,
                    unfocusedTextColor = JarvisTextPrimary,
                    cursorColor = JarvisCyan,
                    focusedContainerColor = JarvisPanelDark,
                    unfocusedContainerColor = JarvisPanelDark
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Gönder Butonu
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(JarvisCyan.copy(alpha = 0.2f))
                    .border(BorderStroke(1.5.dp, JarvisCyan), CircleShape)
                    .clickable(enabled = !isAiLoading && inputText.isNotBlank()) {
                        viewModel.handleUserInput(inputText)
                    }
                    .testTag("chat_send_button"),
                contentAlignment = Alignment.Center
            ) {
                if (isAiLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = JarvisCyan,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Gönder",
                        tint = if (inputText.isNotBlank()) JarvisCyan else JarvisTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun QuickChip(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .border(BorderStroke(1.dp, JarvisBorder), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick),
        color = JarvisSurfaceElevated.copy(alpha = 0.8f)
    ) {
        Text(
            text = label,
            color = JarvisTextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}
