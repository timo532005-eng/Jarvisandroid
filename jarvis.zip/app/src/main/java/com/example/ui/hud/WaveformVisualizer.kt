package com.example.ui.hud

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JarvisAqua
import com.example.ui.theme.JarvisCyan

@Composable
fun WaveformVisualizer(
    isActive: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 28,
    maxHeight: Dp = 36.dp,
    barColor: Color = JarvisCyan
) {
    val transition = rememberInfiniteTransition(label = "WaveformAnim")

    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "WavePhase"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(maxHeight)
    ) {
        val totalWidth = size.width
        val canvasHeight = size.height
        val barWidth = (totalWidth / barCount) * 0.55f
        val spacing = (totalWidth / barCount) * 0.45f

        for (i in 0 until barCount) {
            val normalizedX = i.toFloat() / barCount.toFloat()
            // Simetrik dalga yüksekliği
            val heightMultiplier = if (isActive) {
                val wave1 = kotlin.math.sin(normalizedX * 4f * Math.PI.toFloat() + phase)
                val wave2 = kotlin.math.cos(normalizedX * 2f * Math.PI.toFloat() - phase)
                ((kotlin.math.abs(wave1 + wave2) / 2f).coerceIn(0.15f, 1.0f))
            } else {
                0.12f
            }

            val currentBarHeight = canvasHeight * heightMultiplier
            val left = i * (barWidth + spacing)
            val top = (canvasHeight - currentBarHeight) / 2f

            drawRoundRect(
                color = if (isActive) {
                    if (i % 2 == 0) barColor else JarvisAqua
                } else {
                    barColor.copy(alpha = 0.25f)
                },
                topLeft = Offset(left, top),
                size = Size(barWidth, currentBarHeight),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        }
    }
}
