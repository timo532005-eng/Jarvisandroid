package com.example.ui.hud

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.domain.voice.AssistantVoiceState
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisAqua
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisElectricBlue
import com.example.ui.theme.JarvisWarningAmber
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class SystemHudStatus {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    WAITING_FOR_APPROVAL,
    EXECUTING_ACTION,
    ERROR,
    OFFLINE
}

@Composable
fun ArcReactorHud(
    status: SystemHudStatus,
    size: Dp = 220.dp,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ArcReactor")

    // Dönüş açısı animasyonları (Hıza ve duruma göre dinamik)
    val fastRotationDuration = when (status) {
        SystemHudStatus.THINKING -> 3000
        SystemHudStatus.SPEAKING -> 6000
        SystemHudStatus.LISTENING -> 8000
        SystemHudStatus.EXECUTING_ACTION -> 2500
        else -> 18000
    }

    val rotationCW by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(fastRotationDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RotationCW"
    )

    val rotationCCW by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween((fastRotationDuration * 1.5).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RotationCCW"
    )

    // Nefes alma / Nabız efekti
    val pulseDuration = when (status) {
        SystemHudStatus.LISTENING -> 800
        SystemHudStatus.WAITING_FOR_APPROVAL -> 600
        SystemHudStatus.SPEAKING -> 1000
        SystemHudStatus.ERROR -> 700
        else -> 2200
    }

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(pulseDuration, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    // Duruma göre ana renk
    val primaryColor = when (status) {
        SystemHudStatus.ERROR -> JarvisAlertRed
        SystemHudStatus.WAITING_FOR_APPROVAL -> JarvisWarningAmber
        SystemHudStatus.THINKING -> JarvisAqua
        SystemHudStatus.SPEAKING -> JarvisElectricBlue
        SystemHudStatus.LISTENING -> JarvisCyan
        SystemHudStatus.EXECUTING_ACTION -> JarvisAqua
        SystemHudStatus.OFFLINE -> Color(0xFF3A505F)
        else -> JarvisCyan
    }

    val secondaryColor = when (status) {
        SystemHudStatus.ERROR -> Color(0xFFFF6B8B)
        SystemHudStatus.WAITING_FOR_APPROVAL -> JarvisCyan
        else -> JarvisElectricBlue
    }

    Box(
        modifier = modifier
            .size(size)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.minDimension / 2f

            // 1. Dış Çember ve Parçalı Yaylar (Saat Yönünde)
            rotate(rotationCW, pivot = center) {
                // 3 segmentli dış yay
                val outerArcStroke = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                drawArc(
                    color = primaryColor.copy(alpha = 0.85f),
                    startAngle = 0f,
                    sweepAngle = 75f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius * 0.92f, center.y - radius * 0.92f),
                    size = androidx.compose.ui.geometry.Size(radius * 1.84f, radius * 1.84f),
                    style = outerArcStroke
                )
                drawArc(
                    color = primaryColor.copy(alpha = 0.85f),
                    startAngle = 120f,
                    sweepAngle = 75f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius * 0.92f, center.y - radius * 0.92f),
                    size = androidx.compose.ui.geometry.Size(radius * 1.84f, radius * 1.84f),
                    style = outerArcStroke
                )
                drawArc(
                    color = primaryColor.copy(alpha = 0.85f),
                    startAngle = 240f,
                    sweepAngle = 75f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius * 0.92f, center.y - radius * 0.92f),
                    size = androidx.compose.ui.geometry.Size(radius * 1.84f, radius * 1.84f),
                    style = outerArcStroke
                )

                // Dış çemberdeki ince teknolojik işaretler
                val tickCount = 24
                for (i in 0 until tickCount) {
                    val angle = (i * 360f / tickCount) * (PI / 180f)
                    val innerR = radius * 0.82f
                    val outerR = radius * (if (i % 4 == 0) 0.88f else 0.85f)
                    val startX = center.x + innerR * cos(angle).toFloat()
                    val startY = center.y + innerR * sin(angle).toFloat()
                    val endX = center.x + outerR * cos(angle).toFloat()
                    val endY = center.y + outerR * sin(angle).toFloat()
                    drawLine(
                        color = primaryColor.copy(alpha = if (i % 4 == 0) 0.8f else 0.4f),
                        start = Offset(startX, startY),
                        end = Offset(endX, endY),
                        strokeWidth = if (i % 4 == 0) 2.dp.toPx() else 1.dp.toPx()
                    )
                }
            }

            // 2. Orta Halka (Ters Yönde Dönen)
            rotate(rotationCCW, pivot = center) {
                val midArcStroke = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                drawArc(
                    color = secondaryColor.copy(alpha = 0.7f),
                    startAngle = 45f,
                    sweepAngle = 50f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius * 0.65f, center.y - radius * 0.65f),
                    size = androidx.compose.ui.geometry.Size(radius * 1.3f, radius * 1.3f),
                    style = midArcStroke
                )
                drawArc(
                    color = secondaryColor.copy(alpha = 0.7f),
                    startAngle = 165f,
                    sweepAngle = 50f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius * 0.65f, center.y - radius * 0.65f),
                    size = androidx.compose.ui.geometry.Size(radius * 1.3f, radius * 1.3f),
                    style = midArcStroke
                )
                drawArc(
                    color = secondaryColor.copy(alpha = 0.7f),
                    startAngle = 285f,
                    sweepAngle = 50f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius * 0.65f, center.y - radius * 0.65f),
                    size = androidx.compose.ui.geometry.Size(radius * 1.3f, radius * 1.3f),
                    style = midArcStroke
                )
            }

            // 3. İç Reaktör Çekirdeği (Merkez Parıltı ve Nabız)
            val coreRadius = (radius * 0.38f) * pulseScale
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.75f),
                        primaryColor.copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = coreRadius * 1.3f
                ),
                radius = coreRadius * 1.3f,
                center = center
            )

            // İç çekirdek geometrisi (Arc Reactor Üçgenleri / Petekleri)
            drawCircle(
                color = primaryColor,
                radius = radius * 0.25f,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Merkez nokta
            drawCircle(
                color = primaryColor,
                radius = radius * 0.08f,
                center = center
            )
        }
    }
}
