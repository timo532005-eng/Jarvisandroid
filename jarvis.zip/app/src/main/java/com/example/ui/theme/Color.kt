package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JARVIS Sci-Fi HUD Renk Paleti
val JarvisVoidBlack = Color(0xFF03070A)
val JarvisPanelDark = Color(0xFF071016)
val JarvisSurfaceElevated = Color(0xFF0B151C)

val JarvisCyan = Color(0xFF00E5FF)
val JarvisElectricBlue = Color(0xFF00A3FF)
val JarvisAqua = Color(0xFF00FFB2)

val JarvisAlertRed = Color(0xFFFF3366)
val JarvisWarningAmber = Color(0xFFFFB300)

val JarvisTextPrimary = Color(0xFFE6F7FD)
val JarvisTextSecondary = Color(0xFF82A6BA)
val JarvisBorder = Color(0x4000E5FF)
val JarvisBorderSubtle = Color(0x2000E5FF)
val JarvisGlow = Color(0x3300E5FF)
