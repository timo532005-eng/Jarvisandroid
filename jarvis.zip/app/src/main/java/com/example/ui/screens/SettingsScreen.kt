package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.JarvisViewModel
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisAqua
import com.example.ui.theme.JarvisBorder
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisPanelDark
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.ui.theme.JarvisVoidBlack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()

    var workerUrl by remember(settings.workerBaseUrl) { mutableStateOf(settings.workerBaseUrl) }
    var workerToken by remember(settings.workerAuthToken) { mutableStateOf(settings.workerAuthToken) }
    var directGeminiKey by remember(settings.directGeminiApiKey) { mutableStateOf(settings.directGeminiApiKey) }
    var userName by remember(settings.userName) { mutableStateOf(settings.userName) }

    var speechPitch by remember(settings.speechPitch) { mutableFloatStateOf(settings.speechPitch) }
    var speechSpeed by remember(settings.speechSpeed) { mutableFloatStateOf(settings.speechSpeed) }
    var wakeWordEnabled by remember(settings.wakeWordEnabled) { mutableStateOf(settings.wakeWordEnabled) }

    var isCheckingHealth by remember { mutableStateOf(false) }
    var healthResultText by remember { mutableStateOf<String?>(null) }
    var isHealthSuccess by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisVoidBlack)
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState)
    ) {
        // Üst Başlık
        Text(
            text = "SİSTEM YAPILANDIRMASI // AYARLAR",
            color = JarvisCyan,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
        )
        Text(
            text = "API bağlantıları, ses ve güvenlik parametreleri",
            color = JarvisTextSecondary,
            fontSize = 11.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // 1. Cloudflare Worker Yapılandırması (Birincil Güvenli Köprü)
        SettingsCard(title = "CLOUDFLARE WORKER KÖPRÜSÜ", icon = Icons.Default.Cloud) {
            Text(
                text = "APK içine anahtar gömmeden Gemini, Workers AI ve Tuya çağrılarını güvenle yönlendirir.",
                color = JarvisTextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = workerUrl,
                onValueChange = {
                    workerUrl = it
                    CoroutineScope(Dispatchers.IO).launch {
                        com.example.data.preferences.UserPreferencesDataStore(viewModel.getApplication())
                            .updateWorkerUrl(it)
                    }
                },
                label = { Text("Worker URL'si", color = JarvisTextSecondary) },
                placeholder = { Text("https://jarvis-backend.kullanici.workers.dev", color = Color.Gray, fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth().testTag("setting_worker_url"),
                colors = outlinedColors(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = workerToken,
                onValueChange = {
                    workerToken = it
                    CoroutineScope(Dispatchers.IO).launch {
                        com.example.data.preferences.UserPreferencesDataStore(viewModel.getApplication())
                            .updateWorkerToken(it)
                    }
                },
                label = { Text("Worker Güvenlik Token'ı (X-Jarvis-Token)", color = JarvisTextSecondary) },
                placeholder = { Text("Worker env içinde belirlediğiniz parola", color = Color.Gray, fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth().testTag("setting_worker_token"),
                colors = outlinedColors(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Sağlık / Ping Test Butonu
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .border(BorderStroke(1.dp, JarvisCyan), RoundedCornerShape(8.dp))
                        .clickable(enabled = !isCheckingHealth && workerUrl.isNotBlank()) {
                            isCheckingHealth = true
                            healthResultText = null
                            CoroutineScope(Dispatchers.Main).launch {
                                val res = viewModel.repository.checkBackendHealth()
                                isCheckingHealth = false
                                if (res.isSuccess) {
                                    val health = res.getOrNull()
                                    isHealthSuccess = true
                                    healthResultText = "ÇEVRİMİÇİ: ${health?.service ?: "Worker"} (${health?.status})"
                                } else {
                                    isHealthSuccess = false
                                    healthResultText = "Bağlantı Hatası: ${res.exceptionOrNull()?.message}"
                                }
                            }
                        },
                    color = JarvisCyan.copy(alpha = 0.2f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isCheckingHealth) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = JarvisCyan, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(
                            text = "BAĞLANTIYI TEST ET",
                            color = JarvisCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                if (healthResultText != null) {
                    Text(
                        text = healthResultText!!,
                        color = if (isHealthSuccess) JarvisAqua else JarvisAlertRed,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f).padding(start = 10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 2. Doğrudan Gemini API Anahtarı (Worker Henüz Kurulmadıysa Alternatif)
        SettingsCard(title = "DOĞRUDAN GEMINI API (ALTERNATİF)", icon = Icons.Default.Security) {
            Text(
                text = "Eğer henüz Cloudflare Worker dağıtmadıysanız, Google AI Studio'dan aldığınız Gemini API anahtarını buraya girerek doğrudan Türkçe sohbet edebilirsiniz.",
                color = JarvisTextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = directGeminiKey,
                onValueChange = {
                    directGeminiKey = it
                    CoroutineScope(Dispatchers.IO).launch {
                        com.example.data.preferences.UserPreferencesDataStore(viewModel.getApplication())
                            .updateDirectGeminiApiKey(it)
                    }
                },
                label = { Text("Gemini API Anahtarı (AIza...)", color = JarvisTextSecondary) },
                modifier = Modifier.fillMaxWidth().testTag("setting_direct_gemini_key"),
                colors = outlinedColors(),
                singleLine = true
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3. Ses ve Konuşma Ayarları
        SettingsCard(title = "SES VE ASİSTAN AYARLARI", icon = Icons.Default.RecordVoiceOver) {
            // Hitap Tercihi
            OutlinedTextField(
                value = userName,
                onValueChange = {
                    userName = it
                    CoroutineScope(Dispatchers.IO).launch {
                        com.example.data.preferences.UserPreferencesDataStore(viewModel.getApplication())
                            .updateUserName(it)
                    }
                },
                label = { Text("Asistan Hitap Tercihi", color = JarvisTextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                colors = outlinedColors(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Ön Planda "Jarvis" Uyandırma Kelimesi Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Ön Planda \"Jarvis\" Algılama", color = JarvisTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "Yalnızca uygulama ekranda açıkken 'Jarvis' dendiğinde otomatik dinlemeye geçer. Arka planda asla dinlemez.",
                        color = JarvisTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
                Switch(
                    checked = wakeWordEnabled,
                    onCheckedChange = {
                        wakeWordEnabled = it
                        viewModel.voiceManager.setWakeWordMode(it)
                        CoroutineScope(Dispatchers.IO).launch {
                            com.example.data.preferences.UserPreferencesDataStore(viewModel.getApplication())
                                .updateToggles(it, settings.hapticEnabled, settings.animationsEnabled)
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = JarvisVoidBlack,
                        checkedTrackColor = JarvisCyan,
                        uncheckedTrackColor = JarvisSurfaceElevated
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Konuşma Hızı Slider
            Text(text = "Konuşma Hızı: ${String.format("%.2f", speechSpeed)}x", color = JarvisTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Slider(
                value = speechSpeed,
                onValueChange = {
                    speechSpeed = it
                    CoroutineScope(Dispatchers.IO).launch {
                        com.example.data.preferences.UserPreferencesDataStore(viewModel.getApplication())
                            .updateSpeechSettings(speechPitch, it)
                    }
                },
                valueRange = 0.75f..1.4f,
                colors = SliderDefaults.colors(thumbColor = JarvisCyan, activeTrackColor = JarvisCyan)
            )

            // Ses Tonu (Pitch) Slider
            Text(text = "Ses Tonu (Pitch): ${String.format("%.2f", speechPitch)}x", color = JarvisTextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Slider(
                value = speechPitch,
                onValueChange = {
                    speechPitch = it
                    CoroutineScope(Dispatchers.IO).launch {
                        com.example.data.preferences.UserPreferencesDataStore(viewModel.getApplication())
                            .updateSpeechSettings(it, speechSpeed)
                    }
                },
                valueRange = 0.75f..1.3f,
                colors = SliderDefaults.colors(thumbColor = JarvisAqua, activeTrackColor = JarvisAqua)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 4. Cihaz ve Donanım Bilgisi
        SettingsCard(title = "CİHAZ VE SİSTEM BİLGİSİ", icon = Icons.Default.Info) {
            InfoRow("Hedef Cihaz:", "Samsung Galaxy A73 5G")
            InfoRow("Arayüz Dili:", "Türkçe (tr-TR)")
            InfoRow("Ses Motoru:", "Android TTS / SpeechRecognizer")
            InfoRow("Yerel Veritabanı:", "Room (SQLite) + DataStore")
            InfoRow("Güvenlik Katmanı:", "ActionApprovalManager (Zorunlu Onay)")
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, JarvisBorder), RoundedCornerShape(12.dp)),
        color = JarvisPanelDark
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = JarvisCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = JarvisCyan,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.8.sp
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = JarvisTextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = JarvisTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun outlinedColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = JarvisCyan,
    unfocusedBorderColor = JarvisBorder,
    focusedTextColor = JarvisTextPrimary,
    unfocusedTextColor = JarvisTextPrimary,
    cursorColor = JarvisCyan,
    focusedContainerColor = JarvisSurfaceElevated,
    unfocusedContainerColor = JarvisSurfaceElevated
)
