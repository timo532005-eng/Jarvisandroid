package com.example.ui.hud

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisAqua
import com.example.ui.theme.JarvisBorder
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisPanelDark
import com.example.ui.theme.JarvisSurfaceElevated
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.ui.theme.JarvisVoidBlack
import com.example.ui.theme.JarvisWarningAmber

@Composable
fun HudCard(
    modifier: Modifier = Modifier,
    borderColor: Color = JarvisBorder,
    backgroundColor: Color = JarvisPanelDark,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier
            .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp)),
        color = backgroundColor.copy(alpha = 0.88f)
    ) {
        Box(modifier = Modifier.padding(16.dp)) {
            content()
        }
    }
}

@Composable
fun HudStatusBadge(
    status: SystemHudStatus,
    modifier: Modifier = Modifier
) {
    val (text, color, icon) = when (status) {
        SystemHudStatus.IDLE -> Triple("SİSTEM HAZIR // ÇEVRİMİÇİ", JarvisCyan, Icons.Default.Circle)
        SystemHudStatus.LISTENING -> Triple("SES DİNLENİYOR...", JarvisAqua, Icons.Default.Mic)
        SystemHudStatus.THINKING -> Triple("İŞLENİYOR // ANALİZ", JarvisCyan, Icons.Default.Circle)
        SystemHudStatus.SPEAKING -> Triple("JARVIS KONUŞUYOR...", JarvisCyan, Icons.Default.Circle)
        SystemHudStatus.WAITING_FOR_APPROVAL -> Triple("GÜVENLİK ONAYI BEKLENİYOR", JarvisWarningAmber, Icons.Default.Warning)
        SystemHudStatus.EXECUTING_ACTION -> Triple("İŞLEM GERÇEKLEŞTİRİLİYOR", JarvisAqua, Icons.Default.Circle)
        SystemHudStatus.ERROR -> Triple("SİSTEM UYARISI // HATA", JarvisAlertRed, Icons.Default.Warning)
        SystemHudStatus.OFFLINE -> Triple("BAĞLANTI YOK // ÇEVRİMDIŞI", Color(0xFF6B7A82), Icons.Default.Info)
    }

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.6f)), RoundedCornerShape(16.dp)),
        color = JarvisSurfaceElevated.copy(alpha = 0.9f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(10.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                color = color,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }
    }
}

@Composable
fun HudActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    isPrimary: Boolean = true,
    testTag: String = "hud_action_button"
) {
    val borderColor = if (isPrimary) JarvisCyan else JarvisBorderSubtle
    val bgBrush = if (isPrimary) {
        Brush.horizontalGradient(
            listOf(
                JarvisCyan.copy(alpha = 0.25f),
                JarvisAqua.copy(alpha = 0.15f)
            )
        )
    } else {
        Brush.horizontalGradient(
            listOf(
                JarvisSurfaceElevated.copy(alpha = 0.5f),
                JarvisPanelDark.copy(alpha = 0.5f)
            )
        )
    }

    Box(
        modifier = modifier
            .testTag(testTag)
            .height(48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bgBrush)
            .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isPrimary) JarvisCyan else JarvisTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text.uppercase(),
                color = if (isPrimary) JarvisTextPrimary else JarvisTextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.8.sp
            )
        }
    }
}
