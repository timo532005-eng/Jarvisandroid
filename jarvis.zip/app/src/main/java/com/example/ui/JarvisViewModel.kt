package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.JarvisRepository
import com.example.data.local.ChatMessageEntity
import com.example.data.local.JarvisDatabase
import com.example.data.local.NoteEntity
import com.example.data.local.TaskEntity
import com.example.data.preferences.UserPreferencesDataStore
import com.example.data.preferences.UserSettings
import com.example.data.remote.ActionDto
import com.example.data.remote.TuyaDeviceDto
import com.example.domain.actions.DeviceActionExecutor
import com.example.domain.approval.ActionApprovalManager
import com.example.domain.approval.ActionCategory
import com.example.domain.approval.ApprovalState
import com.example.domain.approval.ProposedAction
import com.example.domain.voice.AssistantVoiceState
import com.example.domain.voice.JarvisVoiceManager
import com.example.ui.hud.SystemHudStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

enum class AppNavScreen {
    HOME,
    CHAT,
    SMART_HOME,
    NOTES_TASKS,
    SETTINGS
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val db = JarvisDatabase.getInstance(application)
    private val prefs = UserPreferencesDataStore(application)
    val repository = JarvisRepository(db.jarvisDao(), prefs)
    val actionExecutor = DeviceActionExecutor(application)
    val approvalManager = ActionApprovalManager(viewModelScope)

    private val _currentScreen = MutableStateFlow(AppNavScreen.HOME)
    val currentScreen: StateFlow<AppNavScreen> = _currentScreen.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _tuyaDevices = MutableStateFlow<List<TuyaDeviceDto>>(emptyList())
    val tuyaDevices: StateFlow<List<TuyaDeviceDto>> = _tuyaDevices.asStateFlow()

    private val _isTuyaLoading = MutableStateFlow(false)
    val isTuyaLoading: StateFlow<Boolean> = _isTuyaLoading.asStateFlow()

    private val _latestNotice = MutableStateFlow<String?>(null)
    val latestNotice: StateFlow<String?> = _latestNotice.asStateFlow()

    // Voice Manager Entegrasyonu
    val voiceManager = JarvisVoiceManager(
        context = application,
        scope = viewModelScope,
        onSpeechRecognized = { spokenText ->
            handleSpokenInput(spokenText)
        }
    )

    val approvalState = approvalManager.state

    // Sistem HUD durumunu birleşik Flow olarak hesapla
    val hudStatus: StateFlow<SystemHudStatus> = combine(
        voiceManager.voiceState,
        approvalManager.state,
        _isAiLoading
    ) { voice, approval, loading ->
        when {
            approval is ApprovalState.Pending -> SystemHudStatus.WAITING_FOR_APPROVAL
            approval is ApprovalState.Executing -> SystemHudStatus.EXECUTING_ACTION
            loading -> SystemHudStatus.THINKING
            voice == AssistantVoiceState.LISTENING -> SystemHudStatus.LISTENING
            voice == AssistantVoiceState.THINKING -> SystemHudStatus.THINKING
            voice == AssistantVoiceState.SPEAKING -> SystemHudStatus.SPEAKING
            voice == AssistantVoiceState.ERROR -> SystemHudStatus.ERROR
            else -> SystemHudStatus.IDLE
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SystemHudStatus.IDLE)

    val messages = repository.messagesFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val notes = repository.notesFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val tasks = repository.tasksFlow.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val settings = repository.settingsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        UserSettings("", "", "", "Efendim", 1.0f, 1.05f, true, true, true)
    )

    fun navigateTo(screen: AppNavScreen) {
        _currentScreen.value = screen
    }

    fun setInputText(text: String) {
        _inputText.value = text
    }

    fun dismissNotice() {
        _latestNotice.value = null
    }

    /**
     * Kullanıcıdan gelen sesli veya yazılı metni işler
     */
    fun handleUserInput(rawText: String) {
        val query = rawText.trim()
        if (query.isBlank()) return
        _inputText.value = ""

        viewModelScope.launch {
            _isAiLoading.value = true

            // Yerel Hızlı Eylem Algılama (Doğrudan Türkçe kalıplar)
            val lower = query.lowercase(Locale("tr", "TR"))

            if (lower.contains("feneri aç") || lower.contains("ışığı aç") && lower.contains("telefon")) {
                proposeFlashlightAction(true)
                _isAiLoading.value = false
                return@launch
            } else if (lower.contains("feneri kapat") || lower.contains("ışığı kapat") && lower.contains("telefon")) {
                proposeFlashlightAction(false)
                _isAiLoading.value = false
                return@launch
            } else if (lower.startsWith("ara ") || lower.contains("numarayı ara")) {
                val number = query.filter { it.isDigit() || it == '+' }
                if (number.isNotBlank()) {
                    proposeDialerAction(number)
                    _isAiLoading.value = false
                    return@launch
                }
            } else if (lower.startsWith("görsel üret") || lower.startsWith("resim çiz") || lower.startsWith("fotoğraf oluştur")) {
                val prompt = query.replace(Regex("(?i)^(görsel üret|resim çiz|fotoğraf oluştur)"), "").trim()
                if (prompt.isNotBlank()) {
                    proposeImageGenAction(prompt)
                    _isAiLoading.value = false
                    return@launch
                }
            }

            // Gemini Yapay Zekâ Yanıtı Alma
            val result = repository.sendUserMessage(query)
            _isAiLoading.value = false

            if (result.isSuccess) {
                val response = result.getOrNull()
                if (response != null) {
                    // Türkçe sesli yanıt ver
                    val currentSettings = settings.value
                    voiceManager.speak(
                        response.reply,
                        pitch = currentSettings.speechPitch,
                        speed = currentSettings.speechSpeed
                    )

                    // Eğer yanıtta eylem varsa GÜVENLİK ONAYINA YÖNLENDİR!
                    if (response.action != null) {
                        handleParsedAction(response.action)
                    }
                }
            } else {
                val errorMsg = result.exceptionOrNull()?.localizedMessage ?: "Bağlantı hatası oluştu."
                _latestNotice.value = "Hata: $errorMsg"
                voiceManager.speak("Efendim bir sorunla karşılaştım: $errorMsg")
            }
        }
    }

    private fun handleSpokenInput(spokenText: String) {
        // Eğer şu an onay bekleyen bir işlem varsa sesli onayı değerlendir
        val currentApproval = approvalManager.state.value
        if (currentApproval is ApprovalState.Pending) {
            val lower = spokenText.lowercase(Locale("tr", "TR"))
            if (lower.contains("evet") || lower.contains("onaylıyorum") || lower.contains("onayla") || lower.contains("yap")) {
                approvalManager.confirmCurrentAction()
                return
            } else if (lower.contains("hayır") || lower.contains("iptal") || lower.contains("vazgeç")) {
                approvalManager.cancelCurrentAction("Sesli komut ile iptal edildi.")
                return
            }
        }

        handleUserInput(spokenText)
    }

    /**
     * Gemini veya yerel mantıktan gelen eylemi ActionApprovalManager'a sunar
     */
    private fun handleParsedAction(action: ActionDto) {
        when (action.type.uppercase()) {
            "FLASHLIGHT" -> {
                val enable = action.param1.uppercase() == "ON" || action.param1.uppercase() == "AÇIK"
                proposeFlashlightAction(enable)
            }
            "OPEN_APP" -> {
                proposeAppLaunch(action.param1)
            }
            "DIAL" -> {
                proposeDialerAction(action.param1)
            }
            "SMS" -> {
                proposeSmsAction(action.param1, action.param2)
            }
            "ALARM" -> {
                proposeAlarmAction(action.param1, action.param2)
            }
            "TIMER" -> {
                val sec = action.param1.toIntOrNull() ?: 60
                proposeTimerAction(sec, action.param2)
            }
            "IMAGE_GEN" -> {
                proposeImageGenAction(action.param1)
            }
            "TUYA" -> {
                proposeTuyaAction(action.param1, action.param2, action.param3)
            }
        }
    }

    // --- Güvenli Eylem Öneri Fonksiyonları (Hepsi Onay Zorunludur) ---

    fun proposeFlashlightAction(enable: Boolean) {
        approvalManager.proposeAction(
            action = ProposedAction(
                category = ActionCategory.FLASHLIGHT,
                title = if (enable) "Feneri Aç" else "Feneri Kapat",
                description = if (enable) "Telefonunuzun kamera flaşı fener olarak açılacak." else "Telefon feneri kapatılacak.",
                parameters = mapOf("Durum" to (if (enable) "AÇIK" else "KAPALI"))
            ),
            onConfirm = {
                actionExecutor.setFlashlight(enable)
            }
        )
    }

    fun proposeAppLaunch(appName: String) {
        approvalManager.proposeAction(
            action = ProposedAction(
                category = ActionCategory.APP_LAUNCH,
                title = "Uygulama Aç: $appName",
                description = "Telefonunuzda '$appName' uygulaması başlatılacak.",
                parameters = mapOf("Uygulama" to appName)
            ),
            onConfirm = {
                actionExecutor.launchApp(appName)
            }
        )
    }

    fun proposeDialerAction(number: String) {
        approvalManager.proposeAction(
            action = ProposedAction(
                category = ActionCategory.PHONE_CALL,
                title = "Telefon Numarası Aktarma",
                description = "$number numarası arama ekranına aktarılacak (Doğrudan arama başlatılmaz, onayınız gerekir).",
                parameters = mapOf("Numara" to number)
            ),
            onConfirm = {
                actionExecutor.openDialer(number)
            }
        )
    }

    fun proposeSmsAction(number: String, messageText: String) {
        approvalManager.proposeAction(
            action = ProposedAction(
                category = ActionCategory.SMS_DRAFT,
                title = "SMS Taslağı Hazırlama",
                description = "$number numarasına SMS taslağı oluşturulup mesaj ekranı açılacak.",
                parameters = mapOf("Alıcı" to number, "Mesaj" to messageText)
            ),
            onConfirm = {
                actionExecutor.draftSms(number, messageText)
            }
        )
    }

    fun proposeAlarmAction(timeStr: String, label: String) {
        val parts = timeStr.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: 8
        val min = parts.getOrNull(1)?.toIntOrNull() ?: 0

        approvalManager.proposeAction(
            action = ProposedAction(
                category = ActionCategory.ALARM,
                title = "Alarm Kur: $timeStr",
                description = "$timeStr için '$label' açıklamalı alarm oluşturulacak.",
                parameters = mapOf("Saat" to timeStr, "Etiket" to label)
            ),
            onConfirm = {
                actionExecutor.setAlarm(hour, min, label)
            }
        )
    }

    fun proposeTimerAction(seconds: Int, label: String) {
        approvalManager.proposeAction(
            action = ProposedAction(
                category = ActionCategory.ALARM,
                title = "Zamanlayıcı Kur",
                description = "$seconds saniyelik zamanlayıcı başlatılacak.",
                parameters = mapOf("Süre" to "$seconds sn", "Etiket" to label)
            ),
            onConfirm = {
                actionExecutor.setTimer(seconds, label)
            }
        )
    }

    fun proposeImageGenAction(prompt: String) {
        approvalManager.proposeAction(
            action = ProposedAction(
                category = ActionCategory.IMAGE_GEN,
                title = "Görsel Üretimi",
                description = "Cloudflare Workers AI ile görsel üretilecek.",
                parameters = mapOf("Açıklama" to prompt)
            ),
            onConfirm = {
                val res = repository.generateImage(prompt)
                if (res.isSuccess) {
                    Result.success("Görsel başarıyla üretildi ve sohbete eklendi.")
                } else {
                    Result.failure(res.exceptionOrNull() ?: Exception("Görsel üretilemedi"))
                }
            }
        )
    }

    fun proposeTuyaAction(deviceIdOrName: String, command: String, value: String) {
        approvalManager.proposeAction(
            action = ProposedAction(
                category = ActionCategory.TUYA_SMART_HOME,
                title = "Tuya Cihaz Kontrolü",
                description = "'$deviceIdOrName' cihazına '$command = $value' komutu gönderilecek.",
                parameters = mapOf("Cihaz" to deviceIdOrName, "Komut" to command, "Değer" to value)
            ),
            onConfirm = {
                val commandList = listOf(mapOf("code" to command, "value" to (value.toBooleanStrictOrNull() ?: value)))
                val res = repository.sendTuyaCommand(deviceIdOrName, commandList)
                if (res.isSuccess) {
                    Result.success("Tuya komutu başarıyla iletildi.")
                } else {
                    Result.failure(res.exceptionOrNull() ?: Exception("Tuya komut iletimi başarısız."))
                }
            }
        )
    }

    // --- Tuya Cihazlarını Yenileme ---
    fun refreshTuyaDevices() {
        viewModelScope.launch {
            _isTuyaLoading.value = true
            val res = repository.getTuyaDevices()
            _isTuyaLoading.value = false
            if (res.isSuccess) {
                _tuyaDevices.value = res.getOrDefault(emptyList())
            } else {
                _latestNotice.value = "Tuya Cihazları Alınamadı: ${res.exceptionOrNull()?.message}"
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
