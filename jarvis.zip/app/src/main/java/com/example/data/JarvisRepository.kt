package com.example.data

import com.example.data.local.ChatMessageEntity
import com.example.data.local.JarvisDao
import com.example.data.local.NoteEntity
import com.example.data.local.TaskEntity
import com.example.data.preferences.UserPreferencesDataStore
import com.example.data.preferences.UserSettings
import com.example.data.remote.ActionDto
import com.example.data.remote.ChatMessageDto
import com.example.data.remote.ChatRequest
import com.example.data.remote.ChatResponse
import com.example.data.remote.DirectGeminiClient
import com.example.data.remote.HealthResponse
import com.example.data.remote.ImageGenRequest
import com.example.data.remote.ImageGenResponse
import com.example.data.remote.JarvisApiClient
import com.example.data.remote.JarvisApiService
import com.example.data.remote.TuyaCommandRequest
import com.example.data.remote.TuyaCommandResponse
import com.example.data.remote.TuyaDeviceDto
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class JarvisRepository(
    private val dao: JarvisDao,
    private val preferencesDataStore: UserPreferencesDataStore
) {
    val messagesFlow: Flow<List<ChatMessageEntity>> = dao.getAllMessages()
    val notesFlow: Flow<List<NoteEntity>> = dao.getAllNotes()
    val tasksFlow: Flow<List<TaskEntity>> = dao.getAllTasks()
    val settingsFlow: Flow<UserSettings> = preferencesDataStore.settingsFlow

    // --- Chat & AI Execution ---
    suspend fun sendUserMessage(
        text: String,
        historyCount: Int = 10
    ): Result<ChatResponse> {
        // 1. Kullanıcı mesajını Room veritabanına kaydet
        val userEntity = ChatMessageEntity(role = "user", content = text)
        dao.insertMessage(userEntity)

        // 2. Güncel ayarları oku
        val settings = settingsFlow.first()
        val recentMessages = dao.getAllMessages().first().takeLast(historyCount)
        val dtoList = recentMessages.map { ChatMessageDto(role = it.role, content = it.content) }

        return try {
            if (settings.workerBaseUrl.isNotBlank()) {
                // Cloudflare Worker üzerinden güvenli çağrı
                val api = JarvisApiClient.createService(settings.workerBaseUrl)
                val response = api.sendChat(
                    token = settings.workerAuthToken.ifBlank { null },
                    request = ChatRequest(messages = dtoList)
                )
                if (response.isSuccessful && response.body() != null) {
                    val chatResponse = response.body()!!
                    dao.insertMessage(
                        ChatMessageEntity(
                            role = "assistant",
                            content = chatResponse.reply,
                            actionJson = chatResponse.action?.raw
                        )
                    )
                    Result.success(chatResponse)
                } else {
                    val errorMsg = response.errorBody()?.string() ?: "Worker yanıt vermedi (${response.code()})"
                    Result.failure(Exception(errorMsg))
                }
            } else if (settings.directGeminiApiKey.isNotBlank()) {
                // Doğrudan Gemini API fallback çağrısı
                val directClient = DirectGeminiClient(settings.directGeminiApiKey)
                val chatResponse = directClient.generateChat(dtoList)
                dao.insertMessage(
                    ChatMessageEntity(
                        role = "assistant",
                        content = chatResponse.reply,
                        actionJson = chatResponse.action?.raw
                    )
                )
                Result.success(chatResponse)
            } else {
                Result.failure(Exception("Henüz bir Cloudflare Worker URL'si veya Gemini API anahtarı yapılandırılmamış. Lütfen Ayarlar sekmesinden yapılandırın."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Görsel Üretimi (Cloudflare Workers AI) ---
    suspend fun generateImage(prompt: String): Result<ImageGenResponse> {
        val settings = settingsFlow.first()
        if (settings.workerBaseUrl.isBlank()) {
            return Result.failure(Exception("Görsel üretimi için Cloudflare Worker gereklidir. Lütfen Ayarlar sekmesinden Worker URL'nizi girin."))
        }
        return try {
            val api = JarvisApiClient.createService(settings.workerBaseUrl)
            val response = api.generateImage(
                token = settings.workerAuthToken.ifBlank { null },
                request = ImageGenRequest(prompt = prompt)
            )
            if (response.isSuccessful && response.body() != null) {
                val imgResponse = response.body()!!
                if (imgResponse.imageBase64 != null) {
                    // Üretilen görseli sohbete kaydet
                    dao.insertMessage(
                        ChatMessageEntity(
                            role = "assistant",
                            content = "İstediğiniz görsel üretildi: \"$prompt\"",
                            imageUrl = imgResponse.imageBase64
                        )
                    )
                }
                Result.success(imgResponse)
            } else {
                Result.failure(Exception("Görsel üretilemedi: ${response.code()} ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Tuya Smart Life Entegrasyonu ---
    suspend fun getTuyaDevices(): Result<List<TuyaDeviceDto>> {
        val settings = settingsFlow.first()
        if (settings.workerBaseUrl.isBlank()) {
            return Result.failure(Exception("Tuya kontrolü için Cloudflare Worker gereklidir."))
        }
        return try {
            val api = JarvisApiClient.createService(settings.workerBaseUrl)
            val response = api.getTuyaDevices(token = settings.workerAuthToken.ifBlank { null })
            if (response.isSuccessful && response.body()?.success == true) {
                Result.success(response.body()!!.devices)
            } else {
                Result.failure(Exception(response.body()?.error ?: "Tuya cihazları alınamadı"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun sendTuyaCommand(
        deviceId: String,
        commands: List<Map<String, Any>>
    ): Result<TuyaCommandResponse> {
        val settings = settingsFlow.first()
        if (settings.workerBaseUrl.isBlank()) {
            return Result.failure(Exception("Cloudflare Worker URL eksik."))
        }
        return try {
            val api = JarvisApiClient.createService(settings.workerBaseUrl)
            val response = api.sendTuyaCommand(
                token = settings.workerAuthToken.ifBlank { null },
                request = TuyaCommandRequest(deviceId = deviceId, commands = commands)
            )
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Tuya komut hatası: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun checkBackendHealth(): Result<HealthResponse> {
        val settings = settingsFlow.first()
        if (settings.workerBaseUrl.isBlank()) {
            return Result.failure(Exception("Worker URL tanımlanmamış"))
        }
        return try {
            val api = JarvisApiClient.createService(settings.workerBaseUrl)
            val response = api.checkHealth()
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Sunucu yanıtı: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Local Notes & Tasks ---
    suspend fun addNote(title: String, content: String, colorTag: String = "CYAN") {
        dao.insertNote(NoteEntity(title = title, content = content, colorTag = colorTag))
    }

    suspend fun deleteNote(id: Long) {
        dao.deleteNote(id)
    }

    suspend fun addTask(title: String, dueDate: String? = null, priority: String = "NORMAL") {
        dao.insertTask(TaskEntity(title = title, dueDate = dueDate, priority = priority))
    }

    suspend fun toggleTaskCompleted(id: Long, completed: Boolean) {
        dao.setTaskCompleted(id, completed)
    }

    suspend fun deleteTask(id: Long) {
        dao.deleteTask(id)
    }

    suspend fun clearChatHistory() {
        dao.clearAllMessages()
    }
}
