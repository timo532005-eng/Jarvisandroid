package com.example.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class DirectGeminiClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateChat(messages: List<ChatMessageDto>, model: String = "gemini-2.5-flash"): ChatResponse = withContext(Dispatchers.IO) {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val systemInstruction = """Sen JARVIS'sin. Kullanıcının Türkçe konuşan, yüksek zekâlı, kibar, profesyonel, fütüristik bilim kurgu kişisel yapay zekâ asistanısın.
Kullanıcıya daima saygılı, net, Türkçe yanıt ver.
ÖNEMLİ GÜVENLİK KURALI: Kullanıcı telefonunda bir işlem yapmanı veya akıllı ev cihazını kontrol etmeni isterse, bu işlemi doğrudan çalıştırma. Bunun yerine yanıtının en sonuna aşağıdaki yapılandırılmış eylem etiketini ekle:
[ACTION:FLASHLIGHT:ON] veya [ACTION:FLASHLIGHT:OFF]
[ACTION:OPEN_APP:UygulamaAdı] (Örnek: [ACTION:OPEN_APP:WhatsApp], [ACTION:OPEN_APP:YouTube])
[ACTION:DIAL:TelefonNumarası] (Örnek: [ACTION:DIAL:112])
[ACTION:SMS:Numara:MesajMetni]
[ACTION:ALARM:Saat(HH:mm):Açıklama] (Örnek: [ACTION:ALARM:07:30:Sabah Uyanma])
[ACTION:TIMER:Saniye:Açıklama]
[ACTION:IMAGE_GEN:İngilizcePrompt]
[ACTION:TUYA:CihazKimliğiVeyaAdı:Komut:Değer] (Örnek: [ACTION:TUYA:salon_isigi:switch_led:true])

Kullanıcıya cevabında da eylemi gerçekleştirmeden önce açıkça soracağını belirt (Örn: "Feneri açmamı onaylıyor musunuz?")."""

        val jsonBody = JSONObject().apply {
            val contentsArray = JSONArray()
            messages.forEach { msg ->
                val contentObj = JSONObject().apply {
                    put("role", if (msg.role == "assistant") "model" else "user")
                    val partsArray = JSONArray().apply {
                        put(JSONObject().put("text", msg.content))
                    }
                    put("parts", partsArray)
                }
                contentsArray.put(contentObj)
            }
            put("contents", contentsArray)
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", systemInstruction))
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 1024)
            })
        }

        val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(endpoint)
            .post(requestBody)
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val errorBody = response.body?.string() ?: "Bilinmeyen hata"
            throw Exception("Gemini API Hatası (${response.code}): $errorBody")
        }

        val responseStr = response.body?.string() ?: throw Exception("Boş yanıt alındı")
        val root = JSONObject(responseStr)
        val candidates = root.optJSONArray("candidates")
        val firstCandidate = candidates?.optJSONObject(0)
        val contentObj = firstCandidate?.optJSONObject("content")
        val parts = contentObj?.optJSONArray("parts")
        val fullText = parts?.optJSONObject(0)?.optString("text") ?: "Jarvis şu an yanıt veremiyor."

        val actionRegex = Regex("\\[ACTION:([^\\]]+)\\]")
        val match = actionRegex.find(fullText)
        var parsedAction: ActionDto? = null
        var cleanText = fullText

        if (match != null) {
            val raw = match.value
            val partsSplit = match.groupValues[1].split(":")
            parsedAction = ActionDto(
                type = partsSplit.getOrElse(0) { "" },
                param1 = partsSplit.getOrElse(1) { "" },
                param2 = partsSplit.getOrElse(2) { "" },
                param3 = partsSplit.getOrElse(3) { "" },
                raw = raw
            )
            cleanText = fullText.replace(raw, "").trim()
        }

        ChatResponse(reply = cleanText, action = parsedAction)
    }
}
