package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ChatMessageDto(
    @Json(name = "role") val role: String,
    @Json(name = "content") val content: String
)

@JsonClass(generateAdapter = true)
data class ChatRequest(
    @Json(name = "messages") val messages: List<ChatMessageDto>,
    @Json(name = "model") val model: String = "gemini-2.5-flash"
)

@JsonClass(generateAdapter = true)
data class ActionDto(
    @Json(name = "type") val type: String,
    @Json(name = "param1") val param1: String = "",
    @Json(name = "param2") val param2: String = "",
    @Json(name = "param3") val param3: String = "",
    @Json(name = "raw") val raw: String = ""
)

@JsonClass(generateAdapter = true)
data class ChatResponse(
    @Json(name = "reply") val reply: String,
    @Json(name = "action") val action: ActionDto? = null
)

@JsonClass(generateAdapter = true)
data class ImageGenRequest(
    @Json(name = "prompt") val prompt: String,
    @Json(name = "model") val model: String = "@cf/black-forest-labs/flux-1-schnell"
)

@JsonClass(generateAdapter = true)
data class ImageGenResponse(
    @Json(name = "success") val success: Boolean = true,
    @Json(name = "prompt") val prompt: String? = null,
    @Json(name = "mime_type") val mimeType: String? = null,
    @Json(name = "image_base64") val imageBase64: String? = null,
    @Json(name = "error") val error: String? = null
)

@JsonClass(generateAdapter = true)
data class TuyaDeviceDto(
    @Json(name = "id") val id: String,
    @Json(name = "name") val name: String,
    @Json(name = "category") val category: String? = null,
    @Json(name = "online") val online: Boolean = false
)

@JsonClass(generateAdapter = true)
data class TuyaDevicesResponse(
    @Json(name = "success") val success: Boolean = false,
    @Json(name = "devices") val devices: List<TuyaDeviceDto> = emptyList(),
    @Json(name = "error") val error: String? = null
)

@JsonClass(generateAdapter = true)
data class TuyaCommandItem(
    @Json(name = "code") val code: String,
    @Json(name = "value") val value: Any
)

@JsonClass(generateAdapter = true)
data class TuyaCommandRequest(
    @Json(name = "device_id") val deviceId: String,
    @Json(name = "commands") val commands: List<Map<String, Any>>
)

@JsonClass(generateAdapter = true)
data class TuyaCommandResponse(
    @Json(name = "success") val success: Boolean = false,
    @Json(name = "device_id") val deviceId: String? = null,
    @Json(name = "message") val message: String? = null,
    @Json(name = "error") val error: String? = null
)

@JsonClass(generateAdapter = true)
data class HealthResponse(
    @Json(name = "status") val status: String,
    @Json(name = "service") val service: String? = null,
    @Json(name = "version") val version: String? = null
)
