package com.example.data.remote

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface JarvisApiService {

    @GET("health")
    suspend fun checkHealth(): Response<HealthResponse>

    @POST("api/chat")
    suspend fun sendChat(
        @Header("X-Jarvis-Token") token: String?,
        @Body request: ChatRequest
    ): Response<ChatResponse>

    @POST("api/generate-image")
    suspend fun generateImage(
        @Header("X-Jarvis-Token") token: String?,
        @Body request: ImageGenRequest
    ): Response<ImageGenResponse>

    @GET("api/tuya/devices")
    suspend fun getTuyaDevices(
        @Header("X-Jarvis-Token") token: String?
    ): Response<TuyaDevicesResponse>

    @POST("api/tuya/command")
    suspend fun sendTuyaCommand(
        @Header("X-Jarvis-Token") token: String?,
        @Body request: TuyaCommandRequest
    ): Response<TuyaCommandResponse>
}

object JarvisApiClient {

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        // Redact authorization and keys from logs as mandated by security rules
        level = HttpLoggingInterceptor.Level.BODY
        redactHeader("X-Jarvis-Token")
        redactHeader("Authorization")
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(loggingInterceptor)
        .build()

    fun createService(baseUrl: String): JarvisApiService {
        val safeUrl = if (baseUrl.isBlank()) "https://example.com/" else {
            if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        }

        val retrofit = Retrofit.Builder()
            .baseUrl(safeUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        return retrofit.create(JarvisApiService::class.java)
    }
}
