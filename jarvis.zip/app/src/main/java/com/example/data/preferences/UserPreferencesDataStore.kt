package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jarvis_preferences")

data class UserSettings(
    val workerBaseUrl: String,
    val workerAuthToken: String,
    val directGeminiApiKey: String,
    val userName: String,
    val speechPitch: Float,
    val speechSpeed: Float,
    val wakeWordEnabled: Boolean,
    val hapticEnabled: Boolean,
    val animationsEnabled: Boolean
)

class UserPreferencesDataStore(private val context: Context) {

    companion object {
        val KEY_WORKER_URL = stringPreferencesKey("worker_base_url")
        val KEY_WORKER_TOKEN = stringPreferencesKey("worker_auth_token")
        val KEY_DIRECT_GEMINI_KEY = stringPreferencesKey("direct_gemini_api_key")
        val KEY_USER_NAME = stringPreferencesKey("user_name")
        val KEY_SPEECH_PITCH = floatPreferencesKey("speech_pitch")
        val KEY_SPEECH_SPEED = floatPreferencesKey("speech_speed")
        val KEY_WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val KEY_HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
        val KEY_ANIMATIONS_ENABLED = booleanPreferencesKey("animations_enabled")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            workerBaseUrl = prefs[KEY_WORKER_URL] ?: "",
            workerAuthToken = prefs[KEY_WORKER_TOKEN] ?: "",
            directGeminiApiKey = prefs[KEY_DIRECT_GEMINI_KEY] ?: "",
            userName = prefs[KEY_USER_NAME] ?: "Efendim",
            speechPitch = prefs[KEY_SPEECH_PITCH] ?: 1.0f,
            speechSpeed = prefs[KEY_SPEECH_SPEED] ?: 1.05f,
            wakeWordEnabled = prefs[KEY_WAKE_WORD_ENABLED] ?: true,
            hapticEnabled = prefs[KEY_HAPTIC_ENABLED] ?: true,
            animationsEnabled = prefs[KEY_ANIMATIONS_ENABLED] ?: true
        )
    }

    suspend fun updateWorkerUrl(url: String) {
        context.dataStore.edit { it[KEY_WORKER_URL] = url.trim().removeSuffix("/") }
    }

    suspend fun updateWorkerToken(token: String) {
        context.dataStore.edit { it[KEY_WORKER_TOKEN] = token.trim() }
    }

    suspend fun updateDirectGeminiApiKey(key: String) {
        context.dataStore.edit { it[KEY_DIRECT_GEMINI_KEY] = key.trim() }
    }

    suspend fun updateUserName(name: String) {
        context.dataStore.edit { it[KEY_USER_NAME] = name.trim() }
    }

    suspend fun updateSpeechSettings(pitch: Float, speed: Float) {
        context.dataStore.edit {
            it[KEY_SPEECH_PITCH] = pitch
            it[KEY_SPEECH_SPEED] = speed
        }
    }

    suspend fun updateToggles(wakeWord: Boolean, haptic: Boolean, animations: Boolean) {
        context.dataStore.edit {
            it[KEY_WAKE_WORD_ENABLED] = wakeWord
            it[KEY_HAPTIC_ENABLED] = haptic
            it[KEY_ANIMATIONS_ENABLED] = animations
        }
    }
}
