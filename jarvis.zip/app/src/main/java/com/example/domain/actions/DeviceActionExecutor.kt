package com.example.domain.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DeviceActionExecutor(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private var isTorchOn = false

    /**
     * Telefon fenerini (kamera flaşı) açar veya kapatır.
     */
    suspend fun setFlashlight(enable: Boolean): Result<String> = withContext(Dispatchers.Main) {
        if (cameraManager == null) {
            return@withContext Result.failure(Exception("Cihazda kamera servisi bulunamadı."))
        }
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return@withContext Result.failure(Exception("Cihazda fener/flaş donanımı bulunamadı."))

            cameraManager.setTorchMode(cameraId, enable)
            isTorchOn = enable
            Result.success(if (enable) "Telefon feneri açıldı." else "Telefon feneri kapatıldı.")
        } catch (e: CameraAccessException) {
            Result.failure(Exception("Kamera erişim hatası: ${e.message}"))
        } catch (e: Exception) {
            Result.failure(Exception("Fener kontrol hatası: ${e.message}"))
        }
    }

    /**
     * Yüklü bir uygulamayı adı veya paket adı üzerinden arayıp açar.
     */
    suspend fun launchApp(appNameQuery: String): Result<String> = withContext(Dispatchers.Main) {
        val pm = context.packageManager
        val query = appNameQuery.trim().lowercase()

        // 1. Bilinen popüler uygulamalar için doğrudan paket adı eşleme
        val knownPackages = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "spotify" to "com.spotify.music",
            "harita" to "com.google.android.apps.maps",
            "maps" to "com.google.android.apps.maps",
            "hesap makinesi" to "com.google.android.calculator",
            "kamera" to "com.sec.android.app.camera",
            "galeri" to "com.sec.android.gallery3d",
            "chrome" to "com.android.chrome",
            "instagram" to "com.instagram.android",
            "telegram" to "org.telegram.messenger",
            "ayarlar" to "com.android.settings"
        )

        val directPkg = knownPackages[query]
        if (directPkg != null) {
            val launchIntent = pm.getLaunchIntentForPackage(directPkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return@withContext Result.success("$appNameQuery uygulaması açıldı.")
            }
        }

        // 2. Yüklü uygulamalar listesinde arama
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolvedList = pm.queryIntentActivities(mainIntent, 0)
        val matchedApp = resolvedList.firstOrNull { resolveInfo ->
            val label = resolveInfo.loadLabel(pm).toString().lowercase()
            label.contains(query) || resolveInfo.activityInfo.packageName.contains(query)
        }

        if (matchedApp != null) {
            val pkg = matchedApp.activityInfo.packageName
            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                val label = matchedApp.loadLabel(pm).toString()
                return@withContext Result.success("$label uygulaması açıldı.")
            }
        }

        Result.failure(Exception("'$appNameQuery' adlı yüklü bir uygulama bulunamadı."))
    }

    /**
     * Telefon arama ekranını (Dialer) numara ile açar (Kullanıcı arama butonuna kendisi basar, doğrudan izinsiz aramaz).
     */
    suspend fun openDialer(phoneNumber: String): Result<String> = withContext(Dispatchers.Main) {
        val cleanNumber = phoneNumber.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
        if (cleanNumber.isBlank()) {
            return@withContext Result.failure(Exception("Geçerli bir telefon numarası belirtilmedi."))
        }
        try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$cleanNumber")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("$cleanNumber numarası arama ekranına aktarıldı.")
        } catch (e: Exception) {
            Result.failure(Exception("Arama ekranı açılamadı: ${e.message}"))
        }
    }

    /**
     * SMS taslağı oluşturup varsayılan mesajlaşma uygulamasını açar.
     */
    suspend fun draftSms(phoneNumber: String, messageText: String): Result<String> = withContext(Dispatchers.Main) {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:${phoneNumber.trim()}")
                putExtra("sms_body", messageText)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("SMS taslağı hazırlandı ve mesajlaşma ekranı açıldı.")
        } catch (e: Exception) {
            Result.failure(Exception("Mesajlaşma uygulaması açılamadı: ${e.message}"))
        }
    }

    /**
     * Alarm kurma ekranını açar.
     */
    suspend fun setAlarm(hour: Int, minutes: Int, message: String): Result<String> = withContext(Dispatchers.Main) {
        try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minutes)
                putExtra(AlarmClock.EXTRA_MESSAGE, message.ifBlank { "Jarvis Hatırlatıcı" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success(String.format("Alarm kuruldu: %02d:%02d (%s)", hour, minutes, message))
        } catch (e: Exception) {
            Result.failure(Exception("Alarm kurulamadı: ${e.message}"))
        }
    }

    /**
     * Zamanlayıcı kurar.
     */
    suspend fun setTimer(seconds: Int, message: String): Result<String> = withContext(Dispatchers.Main) {
        try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message.ifBlank { "Jarvis Zamanlayıcı" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("$seconds saniyelik zamanlayıcı başlatıldı.")
        } catch (e: Exception) {
            Result.failure(Exception("Zamanlayıcı başlatılamadı: ${e.message}"))
        }
    }
}
