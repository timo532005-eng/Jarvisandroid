package com.example.domain.approval

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class ActionCategory(val displayName: String, val iconName: String) {
    FLASHLIGHT("Fener Kontrolü", "Flashlight"),
    APP_LAUNCH("Uygulama Açma", "Apps"),
    PHONE_CALL("Arama Ekranı", "Call"),
    SMS_DRAFT("SMS Taslağı", "Message"),
    ALARM("Alarm / Zamanlayıcı", "Alarm"),
    TUYA_SMART_HOME("Akıllı Ev (Tuya)", "Home"),
    IMAGE_GEN("Görsel Üretimi", "Image")
}

data class ProposedAction(
    val id: String = UUID.randomUUID().toString(),
    val category: ActionCategory,
    val title: String,
    val description: String,
    val parameters: Map<String, String> = emptyMap(),
    val rawActionCode: String = "",
    val timeoutSeconds: Int = 30
)

sealed class ApprovalState {
    object Idle : ApprovalState()
    data class Pending(val action: ProposedAction, val secondsRemaining: Int) : ApprovalState()
    data class Executing(val action: ProposedAction) : ApprovalState()
    data class Completed(val action: ProposedAction, val resultMessage: String) : ApprovalState()
    data class Cancelled(val action: ProposedAction, val reason: String) : ApprovalState()
}

class ActionApprovalManager(
    private val scope: CoroutineScope,
    private val mainDispatcher: CoroutineDispatcher = Dispatchers.Main
) {
    private val _state = MutableStateFlow<ApprovalState>(ApprovalState.Idle)
    val state: StateFlow<ApprovalState> = _state.asStateFlow()

    private var currentExecutionCallback: (suspend () -> Result<String>)? = null
    private var currentCancellationCallback: (() -> Unit)? = null
    private var countdownJob: Job? = null

    /**
     * Yeni bir işlem önerisi sunar ve kullanıcı onayını beklemeye başlar.
     * Gemini veya sistem doğrudan işlemi çalıştıramaz!
     */
    fun proposeAction(
        action: ProposedAction,
        onConfirm: suspend () -> Result<String>,
        onCancel: () -> Unit = {}
    ) {
        countdownJob?.cancel()
        currentExecutionCallback = onConfirm
        currentCancellationCallback = onCancel

        _state.value = ApprovalState.Pending(action, action.timeoutSeconds)

        // 30 saniyelik geri sayım zamanlayıcısı
        countdownJob = scope.launch(mainDispatcher) {
            for (sec in action.timeoutSeconds downTo 1) {
                val current = _state.value
                if (current is ApprovalState.Pending && current.action.id == action.id) {
                    _state.value = current.copy(secondsRemaining = sec)
                    delay(1000)
                } else {
                    return@launch
                }
            }
            // Zaman aşımında otomatik iptal
            val current = _state.value
            if (current is ApprovalState.Pending && current.action.id == action.id) {
                cancelCurrentAction("Onay süresi doldu (Zaman aşımı). İşlem güvenlik nedeniyle iptal edildi.")
            }
        }
    }

    /**
     * Kullanıcı açıkça "Evet, Onayla" butonuna dokunduğunda veya sesle onayladığında çağrılır.
     */
    fun confirmCurrentAction() {
        val currentState = _state.value
        if (currentState !is ApprovalState.Pending) return

        val action = currentState.action
        val callback = currentExecutionCallback
        countdownJob?.cancel()

        _state.value = ApprovalState.Executing(action)

        scope.launch(mainDispatcher) {
            try {
                if (callback != null) {
                    val result = callback.invoke()
                    if (result.isSuccess) {
                        _state.value = ApprovalState.Completed(
                            action,
                            result.getOrDefault("İşlem başarıyla gerçekleştirildi.")
                        )
                    } else {
                        _state.value = ApprovalState.Cancelled(
                            action,
                            "İşlem hatası: ${result.exceptionOrNull()?.localizedMessage ?: "Bilinmeyen hata"}"
                        )
                    }
                } else {
                    _state.value = ApprovalState.Cancelled(action, "İşlem geri çağrısı bulunamadı.")
                }
            } catch (e: Exception) {
                _state.value = ApprovalState.Cancelled(action, "İşlem sırasında istisna oluştu: ${e.message}")
            } finally {
                currentExecutionCallback = null
                currentCancellationCallback = null
            }
        }
    }

    /**
     * Kullanıcı "Hayır, İptal Et" dediğinde veya zaman aşımında çağrılır.
     */
    fun cancelCurrentAction(reason: String = "Kullanıcı tarafından iptal edildi.") {
        val currentState = _state.value
        if (currentState !is ApprovalState.Pending) return

        val action = currentState.action
        countdownJob?.cancel()
        currentCancellationCallback?.invoke()
        currentExecutionCallback = null
        currentCancellationCallback = null

        _state.value = ApprovalState.Cancelled(action, reason)
    }

    fun dismissState() {
        if (_state.value is ApprovalState.Completed || _state.value is ApprovalState.Cancelled) {
            _state.value = ApprovalState.Idle
        }
    }
}
