package com.example.domain.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

enum class AssistantVoiceState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

class JarvisVoiceManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onSpeechRecognized: (String) -> Unit
) {
    private val _voiceState = MutableStateFlow(AssistantVoiceState.IDLE)
    val voiceState: StateFlow<AssistantVoiceState> = _voiceState.asStateFlow()

    private val _lastRecognizedText = MutableStateFlow("")
    val lastRecognizedText: StateFlow<String> = _lastRecognizedText.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    private var isWakeWordModeActive = false
    private var isListeningUserCommand = false
    private var restartListenJob: Job? = null
    private var consecutiveErrors = 0

    init {
        initTts()
        initSpeechRecognizer()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val turkishLocale = Locale("tr", "TR")
                val result = textToSpeech?.setLanguage(turkishLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech?.setLanguage(Locale.getDefault())
                }
                isTtsInitialized = true
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _voiceState.value = AssistantVoiceState.SPEAKING
                    }

                    override fun onDone(utteranceId: String?) {
                        if (_voiceState.value == AssistantVoiceState.SPEAKING) {
                            _voiceState.value = AssistantVoiceState.IDLE
                            // Sesli mod aktifse ve komut sonlandıysa uyandırma kelimesini dinlemeye geri dön
                            if (isWakeWordModeActive) {
                                scheduleWakeWordListen(500)
                            }
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        _voiceState.value = AssistantVoiceState.IDLE
                    }
                })
            }
        }
    }

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _errorMessage.value = "Cihazda ses tanıma servisi bulunamadı."
            return
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _voiceState.value = AssistantVoiceState.LISTENING
                }

                override fun onBeginningOfSpeech() {
                    // Kullanıcı konuşmaya başladı -> Konuşmayı kesme (Barge-in)
                    stopSpeaking()
                    _voiceState.value = AssistantVoiceState.LISTENING
                }

                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    _voiceState.value = AssistantVoiceState.THINKING
                }

                override fun onError(error: Int) {
                    consecutiveErrors++
                    val msg = getSpeechErrorMessage(error)
                    // Hatalarda kontrollü dinleme sürdürme
                    if (isWakeWordModeActive && consecutiveErrors < 5) {
                        scheduleWakeWordListen(1200)
                    } else {
                        _voiceState.value = AssistantVoiceState.IDLE
                        if (consecutiveErrors >= 5) {
                            _errorMessage.value = "Ses algılama duraklatıldı: $msg"
                            isWakeWordModeActive = false
                        }
                    }
                }

                override fun onResults(results: Bundle?) {
                    consecutiveErrors = 0
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spokenText = matches?.firstOrNull()?.trim() ?: ""

                    if (spokenText.isNotBlank()) {
                        _lastRecognizedText.value = spokenText

                        if (isListeningUserCommand) {
                            // Kullanıcı doğrudan komut verdi
                            isListeningUserCommand = false
                            _voiceState.value = AssistantVoiceState.THINKING
                            onSpeechRecognized(spokenText)
                        } else if (isWakeWordModeActive) {
                            // "Jarvis" uyandırma kelimesi kontrolü
                            val lower = spokenText.lowercase(Locale("tr", "TR"))
                            if (lower.contains("jarvis") || lower.contains("servis") || lower.contains("çarvis")) {
                                val commandAfterWakeWord = spokenText.replace(Regex("(?i)jarvis"), "").trim()
                                if (commandAfterWakeWord.length > 2) {
                                    // "Jarvis feneri aç" gibi tek cümlede söylendi
                                    onSpeechRecognized(commandAfterWakeWord)
                                } else {
                                    // Sadece "Jarvis" dendi -> Karşılık verip komut bekle
                                    speak("Dinliyorum efendim.")
                                    isListeningUserCommand = true
                                }
                            } else {
                                // Uyandırma kelimesi değil -> Tekrar dinlemeye dön
                                scheduleWakeWordListen(400)
                            }
                        } else {
                            onSpeechRecognized(spokenText)
                        }
                    } else if (isWakeWordModeActive) {
                        scheduleWakeWordListen(500)
                    } else {
                        _voiceState.value = AssistantVoiceState.IDLE
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partialMatches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = partialMatches?.firstOrNull() ?: ""
                    if (text.isNotBlank()) {
                        _lastRecognizedText.value = text
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    /**
     * Kullanıcı mikrofon butonuna bastığında tek seferlik doğrudan komut dinleme başlatır.
     */
    fun startListeningCommand() {
        stopSpeaking()
        restartListenJob?.cancel()
        consecutiveErrors = 0
        isListeningUserCommand = true
        startRecognizerInternal()
    }

    /**
     * Ön plandayken "Jarvis" uyandırma kelimesi dinleme modunu açar/kapatır.
     */
    fun setWakeWordMode(enabled: Boolean) {
        isWakeWordModeActive = enabled
        restartListenJob?.cancel()
        if (enabled) {
            consecutiveErrors = 0
            scheduleWakeWordListen(200)
        } else {
            speechRecognizer?.stopListening()
            _voiceState.value = AssistantVoiceState.IDLE
        }
    }

    private fun scheduleWakeWordListen(delayMs: Long) {
        if (!isWakeWordModeActive) return
        restartListenJob?.cancel()
        restartListenJob = scope.launch(Dispatchers.Main) {
            delay(delayMs)
            if (isWakeWordModeActive && _voiceState.value != AssistantVoiceState.SPEAKING) {
                startRecognizerInternal()
            }
        }
    }

    private fun startRecognizerInternal() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer?.startListening(intent)
            _voiceState.value = AssistantVoiceState.LISTENING
        } catch (e: Exception) {
            _errorMessage.value = "Dinleme başlatılamadı: ${e.message}"
            _voiceState.value = AssistantVoiceState.IDLE
        }
    }

    /**
     * Jarvis'in konuşmasını anında durdurur (Barge-in / Konuşmayı kesme).
     */
    fun stopSpeaking() {
        if (textToSpeech?.isSpeaking == true) {
            textToSpeech?.stop()
        }
        if (_voiceState.value == AssistantVoiceState.SPEAKING) {
            _voiceState.value = AssistantVoiceState.IDLE
        }
    }

    /**
     * Jarvis'in Türkçe sesle konuşmasını sağlar.
     */
    fun speak(text: String, pitch: Float = 1.0f, speed: Float = 1.05f) {
        if (!isTtsInitialized || text.isBlank()) return
        stopSpeaking()
        textToSpeech?.setPitch(pitch)
        textToSpeech?.setSpeechRate(speed)
        _voiceState.value = AssistantVoiceState.SPEAKING
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply_${System.currentTimeMillis()}")
    }

    fun pause() {
        stopSpeaking()
        restartListenJob?.cancel()
        speechRecognizer?.stopListening()
        _voiceState.value = AssistantVoiceState.IDLE
    }

    fun destroy() {
        pause()
        try {
            speechRecognizer?.destroy()
            textToSpeech?.shutdown()
        } catch (_: Exception) {}
        speechRecognizer = null
        textToSpeech = null
    }

    private fun getSpeechErrorMessage(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "Ses kayıt hatası"
            SpeechRecognizer.ERROR_CLIENT -> "İstemci hatası"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon izni eksik"
            SpeechRecognizer.ERROR_NETWORK -> "Ağ hatası"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Ağ zaman aşımı"
            SpeechRecognizer.ERROR_NO_MATCH -> "Eşleşen ses bulunamadı"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Ses servisi meşgul"
            SpeechRecognizer.ERROR_SERVER -> "Sunucu hatası"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Ses algılanmadı"
            else -> "Hata kodu: $errorCode"
        }
    }
}
