package com.example

import com.example.domain.approval.ActionApprovalManager
import com.example.domain.approval.ActionCategory
import com.example.domain.approval.ApprovalState
import com.example.domain.approval.ProposedAction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
@OptIn(ExperimentalCoroutinesApi::class)
class JarvisSecurityApprovalTest {

    private val testDispatcher = StandardTestDispatcher()
    private val testScope = TestScope(testDispatcher)

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `proposed action enters pending state and does NOT execute callback automatically`() = testScope.runTest {
        val manager = ActionApprovalManager(testScope, testDispatcher)
        var wasExecuted = false

        val action = ProposedAction(
            category = ActionCategory.FLASHLIGHT,
            title = "Feneri Aç",
            description = "Fener açılacak"
        )

        manager.proposeAction(
            action = action,
            onConfirm = {
                wasExecuted = true
                Result.success("Açıldı")
            }
        )

        // İşlem sunulduğu anda onay bekliyor durumuna geçer
        assertTrue(manager.state.value is ApprovalState.Pending)
        assertFalse("Kullanıcı onayı olmadan işlem ASLA çalıştırılmamalıdır!", wasExecuted)

        // Birkaç saniye sonra hala onay bekliyor olmalı
        testScheduler.advanceTimeBy(2000)
        assertFalse(wasExecuted)
        assertTrue(manager.state.value is ApprovalState.Pending)

        // 35 saniye sonra zaman aşımı nedeniyle otomatik iptal edilmeli
        testScheduler.advanceTimeBy(35000)
        assertFalse("Zaman aşımında callback çalışmamalıdır", wasExecuted)
        assertTrue("Zaman aşımında Cancelled durumuna geçmelidir", manager.state.value is ApprovalState.Cancelled)
    }

    @Test
    fun `user confirmation executes callback and transitions to Completed`() = testScope.runTest {
        val manager = ActionApprovalManager(testScope, testDispatcher)
        var wasExecuted = false

        val action = ProposedAction(
            category = ActionCategory.TUYA_SMART_HOME,
            title = "Salon Işığı",
            description = "Işık açılacak"
        )

        manager.proposeAction(
            action = action,
            onConfirm = {
                wasExecuted = true
                Result.success("Tuya komutu başarıyla iletildi")
            }
        )

        // Kullanıcı onay butonuna basar
        manager.confirmCurrentAction()
        advanceUntilIdle()

        assertTrue("Kullanıcı onay verdiğinde işlem çalışmalıdır", wasExecuted)
        assertTrue("Durum Completed olmalıdır", manager.state.value is ApprovalState.Completed)
    }

    @Test
    fun `user cancellation rejects action and prevents callback execution`() = testScope.runTest {
        val manager = ActionApprovalManager(testScope, testDispatcher)
        var wasExecuted = false

        val action = ProposedAction(
            category = ActionCategory.PHONE_CALL,
            title = "Arama Yap",
            description = "112 aranacak"
        )

        manager.proposeAction(
            action = action,
            onConfirm = {
                wasExecuted = true
                Result.success("Arandı")
            }
        )

        // Kullanıcı iptal eder
        manager.cancelCurrentAction("Kullanıcı vazgeçti")
        advanceUntilIdle()

        assertFalse("İptal edilen işlem asla çalıştırılmamalıdır", wasExecuted)
        assertTrue("Durum Cancelled olmalıdır", manager.state.value is ApprovalState.Cancelled)
    }
}
